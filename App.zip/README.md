# Hierarchy Anomaly Dashboard

FastAPI + Jinja2 starter application for monitoring hierarchy-process anomalies. The current version now includes a layered backend scaffold where SQL Server is the read-only external source, PostgreSQL is the main dashboard database, and the Settings page can trigger a backend validation worker.

## Current runtime note

The local machine is using Python `3.14.3`. `pyodbc` did not build successfully in this environment during verification because native Visual C++ build tools or a compatible prebuilt wheel were not available. The application still runs in dummy-data mode because SQL Server is optional and disabled by default.

## Implementation plan

1. Create a FastAPI application with server-rendered Jinja2 templates.
2. Build top-level tabs for `Dashboard`, `Data Quality`, `Hierarchy Process Ext.`, and `Settings`.
3. Use PostgreSQL as the application system of record for layered dashboard data.
4. Pull source rows from SQL Server in read-only mode and load them into PostgreSQL raw and validation layers.
5. Trigger validation-layer processing from the Settings page.
6. Keep dummy source data available for development when SQL Server is disabled.

## Required environment variables

The app reads configuration from `.env`.

| Variable | Purpose |
|---|---|
| `APP_NAME` | Browser title and app header |
| `APP_ENV` | Runtime environment label |
| `APP_HOST` | Uvicorn host |
| `APP_PORT` | Uvicorn port |
| `LOG_LEVEL` | Logging level |
| `SECRET_KEY` | Reserved for future session/security use |
| `CORS_ORIGINS` | Allowed origins, comma-separated |
| `POSTGRES_ENABLED` | Enables PostgreSQL-backed layers and worker actions |
| `POSTGRES_HOST` | PostgreSQL host |
| `POSTGRES_PORT` | PostgreSQL port |
| `POSTGRES_DATABASE` | PostgreSQL database |
| `POSTGRES_USERNAME` | PostgreSQL user |
| `POSTGRES_PASSWORD` | PostgreSQL password |
| `POSTGRES_ECHO` | Enables SQLAlchemy SQL logging |
| `SQLSERVER_ENABLED` | Enables live SQL Server preview route |
| `SQLSERVER_DRIVER` | ODBC driver name |
| `SQLSERVER_HOST` | SQL Server host |
| `SQLSERVER_PORT` | SQL Server port |
| `SQLSERVER_DATABASE` | SQL Server database |
| `SQLSERVER_USERNAME` | Read-only SQL login |
| `SQLSERVER_PASSWORD` | SQL Server password |
| `SQLSERVER_VALIDATION_QUERY` | Read-only query used by the validation worker |

## Folder structure

```text
Customer_Master_Dashboard/
├── app/
│   ├── config.py
│   ├── database.py
│   ├── logging_config.py
│   ├── main.py
│   ├── models.py
│   └── services/
│       ├── anomalies.py
│       ├── postgres_store.py
│       └── sqlserver_reader.py
│       └── validation_pipeline.py
├── static/
│   └── css/
│       └── styles.css
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── data_quality.html
│   ├── hierarchy_process_ext.html
│   └── settings.html
├── .env.example
├── README.md
└── requirements.txt
```

## Features

- Top navigation tabs for `Dashboard`, `Data Quality`, and `Settings`
- Left-side anomaly navigation within `Data Quality`
- Clean green-and-white dashboard theme
- PostgreSQL-backed validation run tracking
- Settings button to start a backend validation-layer worker
- Dummy anomaly metrics and sample records
- JSON APIs for health and anomaly data
- SQL Server preview endpoint with read-only query validation

## Backend architecture

The application now follows a layered data flow:

1. SQL Server is treated as a read-only external source.
2. A backend worker pulls hierarchy records from SQL Server using a single safe `SELECT` query.
3. The worker loads those rows into the PostgreSQL raw layer table `raw_hierarchy_records`.
4. The worker generates validation issues and stores them in `validation_issues`.
5. The dashboard reads the latest completed validation run from PostgreSQL and uses that as the primary data source.

Tables added in PostgreSQL:

- `validation_runs`
- `raw_hierarchy_records`
- `validation_issues`

## Setup commands

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

## Optional SQL Server driver setup

Install SQL Server support only when you are ready to connect to SSMS-backed data and the machine has the required ODBC/native tooling.

```powershell
pip install pyodbc
```

If that fails, use a Python version with supported wheels such as Python `3.12` or install Microsoft C++ Build Tools and the SQL Server ODBC driver first.

## Backend run command

```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Frontend run command

There is no separate frontend build tool in this version. The UI is rendered by FastAPI + Jinja2.

Open:

```text
http://127.0.0.1:8000
```

## Sample `.env` values

```env
APP_NAME=Hierarchy Anomaly Dashboard
APP_ENV=development
APP_HOST=127.0.0.1
APP_PORT=8000
LOG_LEVEL=INFO
SECRET_KEY=change-me
CORS_ORIGINS=http://127.0.0.1:8000,http://localhost:8000
POSTGRES_ENABLED=true
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DATABASE=hierarchy_dashboard
POSTGRES_USERNAME=postgres
POSTGRES_PASSWORD=change-me
POSTGRES_ECHO=false
SQLSERVER_ENABLED=false
SQLSERVER_DRIVER=ODBC Driver 17 for SQL Server
SQLSERVER_HOST=localhost
SQLSERVER_PORT=1433
SQLSERVER_DATABASE=CustomerMaster
SQLSERVER_USERNAME=readonly_user
SQLSERVER_PASSWORD=change-me
SQLSERVER_VALIDATION_QUERY=SELECT customer_code, node_code, parent_node_code, node_name, owner_name, owner_active, branch_name FROM dbo.customer_hierarchy
```

## Basic test steps

1. Start the app with Uvicorn.
2. Open `http://127.0.0.1:8000`.
3. Confirm the top tabs render correctly.
4. Open `Data Quality` and switch between anomaly items in the side navigation.
5. Open `Settings` and verify PostgreSQL and SQL Server environment values render.
6. Click `Run Validation Layer`.
7. Confirm a validation run appears on the Settings page.
8. Check `http://127.0.0.1:8000/api/health`.
9. Check `http://127.0.0.1:8000/api/anomalies`.
10. Check `http://127.0.0.1:8000/api/validation-runs/latest`.
11. Check `http://127.0.0.1:8000/api/sqlserver-preview`.

## Data source notes

- PostgreSQL is now the intended primary dashboard database.
- The dashboard reads the latest completed validation results from PostgreSQL when enabled.
- SQL Server reads still go through `app/services/sqlserver_reader.py`.
- Only single-statement `SELECT` queries are permitted.
- Dangerous SQL keywords are rejected before execution.
- SQL Server must remain read-only.
- When SQL Server is disabled, the validation worker uses dummy source rows so the pipeline can still be tested.
- The current local verification on July 21, 2026 was performed without a live SQL Server driver.

## Placeholder integrations

- Google Search API: not implemented
- Hoovers / D&B integration: not implemented
- Live SQL Server anomaly extraction: scaffolded, not yet wired into the dashboard views
