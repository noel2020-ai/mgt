from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = Field(default="Hierarchy Anomaly Dashboard", alias="APP_NAME")
    app_env: str = Field(default="development", alias="APP_ENV")
    app_host: str = Field(default="127.0.0.1", alias="APP_HOST")
    app_port: int = Field(default=8000, alias="APP_PORT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    secret_key: str = Field(default="change-me", alias="SECRET_KEY")
    cors_origins: str = Field(
        default="http://127.0.0.1:8000,http://localhost:8000",
        alias="CORS_ORIGINS",
    )

    postgres_enabled: bool = Field(default=False, alias="POSTGRES_ENABLED")
    postgres_host: str = Field(default="localhost", alias="POSTGRES_HOST")
    postgres_port: int = Field(default=5432, alias="POSTGRES_PORT")
    postgres_database: str = Field(default="hierarchy_dashboard", alias="POSTGRES_DATABASE")
    postgres_username: str = Field(default="postgres", alias="POSTGRES_USERNAME")
    postgres_password: str = Field(default="change-me", alias="POSTGRES_PASSWORD")
    postgres_echo: bool = Field(default=False, alias="POSTGRES_ECHO")

    sqlserver_enabled: bool = Field(default=False, alias="SQLSERVER_ENABLED")
    sqlserver_driver: str = Field(
        default="ODBC Driver 17 for SQL Server", alias="SQLSERVER_DRIVER"
    )
    sqlserver_host: str = Field(default="localhost", alias="SQLSERVER_HOST")
    sqlserver_port: int = Field(default=1433, alias="SQLSERVER_PORT")
    sqlserver_database: str = Field(default="CustomerMaster", alias="SQLSERVER_DATABASE")
    sqlserver_username: str = Field(default="readonly_user", alias="SQLSERVER_USERNAME")
    sqlserver_password: str = Field(default="change-me", alias="SQLSERVER_PASSWORD")
    sqlserver_validation_query: str = Field(
        default=(
            "SELECT customer_code, node_code, parent_node_code, node_name, owner_name, "
            "owner_active, branch_name FROM dbo.customer_hierarchy"
        ),
        alias="SQLSERVER_VALIDATION_QUERY",
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def sqlserver_url(self) -> str:
        driver = self.sqlserver_driver.replace(" ", "+")
        return (
            f"mssql+pyodbc://{self.sqlserver_username}:{self.sqlserver_password}"
            f"@{self.sqlserver_host}:{self.sqlserver_port}/{self.sqlserver_database}"
            f"?driver={driver}&TrustServerCertificate=yes"
        )


@lru_cache
def get_settings() -> Settings:
    return Settings()
