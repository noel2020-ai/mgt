from pathlib import Path
import logging

from fastapi import BackgroundTasks, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import SQLAlchemyError

from app.config import get_settings
from app.database import get_session_factory
from app.logging_config import configure_logging
from app.schemas import ApiResponse
from app.services.anomalies import build_dashboard_summary, get_anomaly, list_anomalies
from app.services.postgres_store import initialize_schema
from app.services.sqlserver_reader import SQLServerReadOnlyError, fetch_rows
from app.services.validation_pipeline import (
    get_latest_validation_run,
    process_validation_layer,
    serialize_validation_run,
)

settings = get_settings()
configure_logging(settings.log_level)
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title=settings.app_name)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


@app.on_event("startup")
async def startup_event() -> None:
    if settings.postgres_enabled:
        try:
            initialize_schema()
        except Exception:
            logger.exception("PostgreSQL schema initialization failed during startup.")


def render(
    request: Request,
    template_name: str,
    page_title: str,
    active_tab: str,
    **context: object,
) -> HTMLResponse:
    return templates.TemplateResponse(
        request=request,
        name=template_name,
        context={
            "app_name": settings.app_name,
            "page_title": page_title,
            "active_tab": active_tab,
            **context,
        },
    )


@app.get("/", response_class=HTMLResponse)
async def dashboard_page(request: Request) -> HTMLResponse:
    logger.info("Rendering dashboard page.")
    return render(
        request=request,
        template_name="dashboard.html",
        page_title="Dashboard",
        active_tab="dashboard",
        summary=build_dashboard_summary(),
        anomalies=list_anomalies(),
    )


@app.get("/data-quality", response_class=HTMLResponse)
async def data_quality_page(
    request: Request,
    anomaly: str | None = Query(default=None),
) -> HTMLResponse:
    anomalies = list_anomalies()
    selected = get_anomaly(anomaly) if anomaly else anomalies[0]
    if selected is None:
        raise HTTPException(status_code=404, detail="Anomaly not found.")

    logger.info("Rendering data quality page for anomaly '%s'.", selected["id"])
    return render(
        request=request,
        template_name="data_quality.html",
        page_title="Data Quality",
        active_tab="data_quality",
        anomalies=anomalies,
        selected_anomaly=selected,
    )


@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request) -> HTMLResponse:
    logger.info("Rendering settings page.")
    latest_run = None
    if settings.postgres_enabled:
        try:
            session_factory = get_session_factory()
            with session_factory() as session:
                latest_run = serialize_validation_run(get_latest_validation_run(session))
        except (RuntimeError, SQLAlchemyError):
            logger.exception("Failed to load latest validation run for settings page.")

    return render(
        request=request,
        template_name="settings.html",
        page_title="Settings",
        active_tab="settings",
        postgres_enabled=settings.postgres_enabled,
        postgres_host=settings.postgres_host,
        postgres_database=settings.postgres_database,
        sqlserver_enabled=settings.sqlserver_enabled,
        sqlserver_host=settings.sqlserver_host,
        sqlserver_database=settings.sqlserver_database,
        latest_run=latest_run,
        status_message=request.query_params.get("message"),
        status_level=request.query_params.get("level", "success"),
    )


@app.get("/hierarchy-process-ext", response_class=HTMLResponse)
async def hierarchy_process_ext_page(request: Request) -> HTMLResponse:
    logger.info("Rendering hierarchy process extension page.")
    extension_items = [
        {
            "id": "process-gaps",
            "label": "Process Gaps",
            "severity": "high",
            "count": 5,
            "description": "Placeholder checks for missing steps or broken handoffs in the hierarchy process flow.",
            "samples": [
                {"customer_code": "CUST-0401", "node": "Zone North", "issue": "Approval step missing"},
                {"customer_code": "CUST-0408", "node": "Zone West", "issue": "Handoff not completed"},
            ],
        },
        {
            "id": "timing-delays",
            "label": "Timing Delays",
            "severity": "medium",
            "count": 9,
            "description": "Placeholder checks for delays between process stages and refresh milestones.",
            "samples": [
                {"customer_code": "CUST-0502", "node": "Retail Cluster A", "issue": "Stage delayed by 2 days"},
                {"customer_code": "CUST-0510", "node": "Retail Cluster D", "issue": "Refresh overdue"},
            ],
        },
        {
            "id": "owner-escalations",
            "label": "Owner Escalations",
            "severity": "critical",
            "count": 2,
            "description": "Placeholder checks for unresolved hierarchy process items that require escalation.",
            "samples": [
                {"customer_code": "CUST-0601", "node": "National Accounts", "issue": "Escalation unresolved"},
                {"customer_code": "CUST-0604", "node": "Distributor Chain", "issue": "Owner not assigned"},
            ],
        },
    ]
    selected_id = request.query_params.get("item")
    selected_item = next(
        (item for item in extension_items if item["id"] == selected_id),
        extension_items[0],
    )
    return render(
        request=request,
        template_name="hierarchy_process_ext.html",
        page_title="Hierarchy Process Ext.",
        active_tab="hierarchy_process_ext",
        extension_items=extension_items,
        selected_item=selected_item,
    )


def run_validation_worker() -> None:
    session_factory = get_session_factory()
    with session_factory() as session:
        process_validation_layer(session)


@app.post("/settings/run-validation")
async def trigger_validation_run(background_tasks: BackgroundTasks) -> RedirectResponse:
    if not settings.postgres_enabled:
        return RedirectResponse(
            url="/settings?level=error&message=PostgreSQL+must+be+enabled+before+running+the+validation+layer.",
            status_code=303,
        )

    try:
        initialize_schema()
    except Exception:
        logger.exception("Failed to initialize schema before starting validation.")
        return RedirectResponse(
            url="/settings?level=error&message=PostgreSQL+schema+initialization+failed.",
            status_code=303,
        )

    background_tasks.add_task(run_validation_worker)
    return RedirectResponse(
        url="/settings?level=success&message=Validation+layer+worker+started.",
        status_code=303,
    )


@app.get("/api/health", response_model=ApiResponse)
async def health_check() -> ApiResponse:
    return ApiResponse(
        status="success",
        message="Application is running.",
        data={
            "environment": settings.app_env,
            "postgres_enabled": settings.postgres_enabled,
            "sqlserver_enabled": settings.sqlserver_enabled,
        },
    )


@app.get("/api/anomalies", response_model=ApiResponse)
async def anomalies_api() -> ApiResponse:
    data = {"items": list_anomalies(), "summary": build_dashboard_summary()}
    return ApiResponse(status="success", message="Anomalies loaded.", data=data)


@app.get("/api/sqlserver-preview", response_model=ApiResponse)
async def sqlserver_preview(query: str = Query(default="SELECT TOP 10 name FROM sys.tables")) -> ApiResponse:
    if not settings.sqlserver_enabled:
        return ApiResponse(
            status="success",
            message="SQL Server integration is disabled. Returning placeholder response.",
            data={"items": [], "query": query},
        )

    try:
        rows = fetch_rows(settings, query)
    except SQLServerReadOnlyError as exc:
        logger.warning("Rejected SQL Server query: %s", exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception:
        logger.exception("SQL Server preview query failed.")
        raise HTTPException(status_code=500, detail="SQL Server preview query failed.") from None

    return ApiResponse(
        status="success",
        message="SQL Server preview query completed.",
        data={"items": rows, "query": query},
    )


@app.get("/api/validation-runs/latest", response_model=ApiResponse)
async def latest_validation_run_api() -> ApiResponse:
    if not settings.postgres_enabled:
        return ApiResponse(
            status="success",
            message="PostgreSQL is disabled.",
            data={"run": None},
        )

    try:
        session_factory = get_session_factory()
        with session_factory() as session:
            run = serialize_validation_run(get_latest_validation_run(session))
    except Exception:
        logger.exception("Failed to load latest validation run.")
        raise HTTPException(status_code=500, detail="Failed to load latest validation run.") from None

    return ApiResponse(
        status="success",
        message="Latest validation run loaded.",
        data={"run": run},
    )
