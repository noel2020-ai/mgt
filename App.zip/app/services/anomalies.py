from collections import Counter

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_session_factory
from app.services.validation_pipeline import get_validation_anomalies, get_validation_summary


DUMMY_ANOMALIES = [
    {
        "id": "missing-parent",
        "label": "Missing Parent Links",
        "severity": "high",
        "count": 12,
        "description": "Records point to a parent node that does not exist in the current hierarchy snapshot.",
        "samples": [
            {"customer_code": "CUST-0011", "node": "South Cluster", "issue": "Parent not found"},
            {"customer_code": "CUST-0084", "node": "Metro Tier 2", "issue": "Parent archived"},
        ],
    },
    {
        "id": "duplicate-assignments",
        "label": "Duplicate Assignments",
        "severity": "medium",
        "count": 7,
        "description": "The same customer appears under multiple active hierarchy branches.",
        "samples": [
            {"customer_code": "CUST-0140", "node": "Regional East", "issue": "Duplicated in branch West"},
            {"customer_code": "CUST-0193", "node": "Key Accounts", "issue": "Duplicated in branch National"},
        ],
    },
    {
        "id": "circular-reference",
        "label": "Circular References",
        "severity": "critical",
        "count": 3,
        "description": "A hierarchy path loops back to an ancestor, which breaks traversal and roll-up logic.",
        "samples": [
            {"customer_code": "CUST-0221", "node": "Distributor Group A", "issue": "Cycle depth 4"},
            {"customer_code": "CUST-0222", "node": "Distributor Group B", "issue": "Cycle depth 3"},
        ],
    },
    {
        "id": "inactive-owner",
        "label": "Inactive Owner Mapping",
        "severity": "low",
        "count": 15,
        "description": "Hierarchy owners are inactive or missing from the current ownership reference list.",
        "samples": [
            {"customer_code": "CUST-0310", "node": "Outlet Segment 3", "issue": "Owner inactive"},
            {"customer_code": "CUST-0324", "node": "Outlet Segment 7", "issue": "Owner missing"},
        ],
    },
]


def list_anomalies() -> list[dict]:
    settings = get_settings()
    if settings.postgres_enabled:
        try:
            session_factory = get_session_factory()
            with session_factory() as session:
                anomalies = _postgres_anomalies(session)
                if anomalies:
                    return anomalies
        except (RuntimeError, SQLAlchemyError):
            pass
    return DUMMY_ANOMALIES


def get_anomaly(anomaly_id: str) -> dict | None:
    for anomaly in DUMMY_ANOMALIES:
        if anomaly["id"] == anomaly_id:
            return anomaly
    return None


def build_dashboard_summary() -> dict:
    settings = get_settings()
    if settings.postgres_enabled:
        try:
            session_factory = get_session_factory()
            with session_factory() as session:
                summary = get_validation_summary(session)
                if summary:
                    return summary
        except (RuntimeError, SQLAlchemyError):
            pass

    anomalies = list_anomalies()
    severity_counts = Counter(item["severity"] for item in anomalies)

    return {
        "total_anomalies": len(anomalies),
        "total_records_flagged": sum(item["count"] for item in anomalies),
        "critical_items": severity_counts.get("critical", 0),
        "high_items": severity_counts.get("high", 0),
        "trend_text": "3 anomaly categories increased compared with the last refresh.",
        "pipeline_status": "Dummy data mode",
    }


def _postgres_anomalies(session: Session) -> list[dict] | None:
    return get_validation_anomalies(session)
