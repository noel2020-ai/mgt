from app.config import get_settings
from app.reference.hierarchy_process_definitions import (
    HIERARCHY_PROCESS_ITEMS,
    HIERARCHY_PROCESS_REVIEW_COLUMNS,
    HIERARCHY_PROCESS_REVIEW_FIELDS,
    build_hierarchy_item_payload,
)
from app.services.sqlserver_reader import fetch_rows
from app.services.sqlserver_reference_queries import (
    build_reference_count_query,
    build_reference_select_query,
    build_review_query,
)


def list_hierarchy_items() -> list[dict]:
    return [_serialize_item(item, include_rows=True) for item in HIERARCHY_PROCESS_ITEMS]


def get_hierarchy_item(item_id: str) -> dict | None:
    for item in HIERARCHY_PROCESS_ITEMS:
        if item["id"] == item_id:
            return _serialize_item(item, include_rows=True)
    return None


def search_hierarchy_reviews(item_id: str, review_tab: str, search_field: str, search_text: str) -> dict | None:
    item = next((candidate for candidate in HIERARCHY_PROCESS_ITEMS if candidate["id"] == item_id), None)
    if item is None:
        return None

    if not search_text.strip():
        return {
            "review_tab": review_tab,
            "search_field": search_field,
            "search_text": search_text,
            "columns": HIERARCHY_PROCESS_REVIEW_COLUMNS,
            "rows": [],
            "message": "Enter a search term to review related records.",
        }

    settings = get_settings()
    if not settings.sqlserver_enabled:
        return {
            "review_tab": review_tab,
            "search_field": search_field,
            "search_text": search_text,
            "columns": HIERARCHY_PROCESS_REVIEW_COLUMNS,
            "rows": [],
            "message": "SQL Server is disabled.",
        }

    query = build_review_query(
        item["source_table"],
        HIERARCHY_PROCESS_REVIEW_COLUMNS,
        HIERARCHY_PROCESS_REVIEW_FIELDS,
        search_field,
        search_text,
        settings.sqlserver_preview_row_limit,
        where_clause=item.get("where_clause", "1 = 1"),
    )
    rows = fetch_rows(settings, query)
    return {
        "review_tab": review_tab,
        "search_field": search_field,
        "search_text": search_text,
        "columns": HIERARCHY_PROCESS_REVIEW_COLUMNS,
        "rows": rows,
        "message": f"{len(rows)} related records found.",
    }


def _serialize_item(item: dict, *, include_rows: bool) -> dict:
    settings = get_settings()
    if settings.sqlserver_enabled:
        rows = fetch_rows(settings, build_reference_select_query(item, settings.sqlserver_preview_row_limit)) if include_rows else []
        count_rows = fetch_rows(settings, build_reference_count_query(item))
        count = int(count_rows[0].get("row_count", 0) or 0) if count_rows else 0
    else:
        rows = []
        count = 0
    return build_hierarchy_item_payload(item, count=count, rows=rows)
