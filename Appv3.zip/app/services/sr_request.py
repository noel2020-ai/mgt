from app.config import get_settings
from app.reference.sr_request_definitions import SR_REQUEST_DEFINITION
from app.services.sqlserver_reader import fetch_rows
from app.services.sqlserver_reference_queries import build_reference_select_query


def get_sr_request_payload() -> dict:
    settings = get_settings()
    if settings.sqlserver_enabled:
        rows = fetch_rows(settings, build_reference_select_query(SR_REQUEST_DEFINITION, settings.sqlserver_preview_row_limit))
    else:
        rows = []
    return {
        "label": SR_REQUEST_DEFINITION["label"],
        "description": SR_REQUEST_DEFINITION["description"],
        "columns": SR_REQUEST_DEFINITION["result_columns"],
        "rows": rows,
        "source_table": SR_REQUEST_DEFINITION["source_table"],
    }
