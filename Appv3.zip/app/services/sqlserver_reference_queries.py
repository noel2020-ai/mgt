import re

from app.services.sqlserver_reader import SQLServerReadOnlyError

IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_ ]*$")
ALIAS_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
FORBIDDEN_CLAUSE_PATTERN = re.compile(
    r"\b(insert|update|delete|drop|alter|truncate|merge|exec|create|replace|grant|revoke)\b",
    re.IGNORECASE,
)


def quote_identifier(value: str) -> str:
    if not IDENTIFIER_PATTERN.match(value):
        raise SQLServerReadOnlyError(f"Unsafe SQL identifier: {value}")
    return f"[{value}]"


def quote_alias(value: str) -> str:
    if not ALIAS_PATTERN.match(value):
        raise SQLServerReadOnlyError(f"Unsafe SQL alias: {value}")
    return f"[{value}]"


def escape_sql_string(value: str) -> str:
    return value.replace("'", "''")


def validate_where_clause(where_clause: str) -> str:
    normalized = where_clause.strip()
    if not normalized:
        return "1 = 1"
    if ";" in normalized:
        raise SQLServerReadOnlyError("Reference where clause cannot contain semicolons.")
    if FORBIDDEN_CLAUSE_PATTERN.search(normalized):
        raise SQLServerReadOnlyError("Reference where clause contains forbidden SQL keywords.")
    return normalized


def build_reference_select_query(definition: dict, row_limit: int) -> str:
    select_parts = [
        f"{quote_identifier(column['column'])} AS {quote_alias(column['key'])}"
        for column in definition["result_columns"]
    ]
    return (
        f"SELECT TOP {int(row_limit)} {', '.join(select_parts)} "
        f"FROM {quote_identifier(definition['source_table'])} "
        f"WHERE {validate_where_clause(definition.get('where_clause', '1 = 1'))}"
    )


def build_reference_count_query(definition: dict) -> str:
    return (
        f"SELECT COUNT(1) AS [row_count] "
        f"FROM {quote_identifier(definition['source_table'])} "
        f"WHERE {validate_where_clause(definition.get('where_clause', '1 = 1'))}"
    )


def build_like_pattern(search_text: str) -> str:
    normalized = search_text.strip()
    escaped = escape_sql_string(normalized)
    if "*" in escaped:
        return escaped.replace("*", "%")
    return f"%{escaped}%"


def like_expression(column_name: str, pattern: str) -> str:
    column = quote_identifier(column_name)
    return f"UPPER(ISNULL(CAST({column} AS NVARCHAR(255)), '')) LIKE UPPER('{pattern}')"


def build_review_where_clause(search_fields: list[dict], search_field: str, search_text: str) -> str:
    pattern = build_like_pattern(search_text)
    if search_field == "all":
        expressions = [
            like_expression(field["column"], pattern)
            for field in search_fields
            if field["column"] is not None
        ]
        return " OR ".join(f"({expression})" for expression in expressions) or "1 = 0"

    for field in search_fields:
        if field["key"] == search_field:
            return like_expression(field["column"], pattern)

    raise SQLServerReadOnlyError(f"Unsupported review search field: {search_field}")


def build_review_query(
    source_table: str,
    result_columns: list[dict],
    search_fields: list[dict],
    search_field: str,
    search_text: str,
    row_limit: int,
    *,
    where_clause: str = "1 = 1",
) -> str:
    select_parts = [
        f"{quote_identifier(column['column'])} AS {quote_alias(column['key'])}"
        for column in result_columns
    ]
    base_where = validate_where_clause(where_clause)
    search_where = build_review_where_clause(search_fields, search_field, search_text)
    return (
        f"SELECT TOP {int(row_limit)} {', '.join(select_parts)} "
        f"FROM {quote_identifier(source_table)} "
        f"WHERE ({base_where}) AND ({search_where})"
    )
