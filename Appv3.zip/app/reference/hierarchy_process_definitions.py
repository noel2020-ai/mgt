from app.reference.review_definitions import REVIEW_TABS


HIERARCHY_PROCESS_ITEMS = [
    {
        "id": "process-gaps",
        "label": "Process Gaps",
        "severity": "high",
        "description": "Checks for missing steps or broken handoffs in the hierarchy process flow.",
        "source_table": "Hierarchy_Process_Table",
        "where_clause": "ProcessStatus = 'Gap'",
        "result_columns": [
            {"key": "customer_code", "label": "Customer Code", "column": "CustomerCode"},
            {"key": "node", "label": "Hierarchy Node", "column": "HierarchyNode"},
            {"key": "issue", "label": "Issue", "column": "IssueDescription"},
        ],
    },
    {
        "id": "timing-delays",
        "label": "Timing Delays",
        "severity": "medium",
        "description": "Checks for delays between process stages and refresh milestones.",
        "source_table": "Hierarchy_Process_Table",
        "where_clause": "ProcessStatus = 'Delay'",
        "result_columns": [
            {"key": "customer_code", "label": "Customer Code", "column": "CustomerCode"},
            {"key": "node", "label": "Hierarchy Node", "column": "HierarchyNode"},
            {"key": "issue", "label": "Issue", "column": "IssueDescription"},
        ],
    },
    {
        "id": "owner-escalations",
        "label": "Owner Escalations",
        "severity": "critical",
        "description": "Checks for unresolved hierarchy process items that require escalation.",
        "source_table": "Hierarchy_Process_Table",
        "where_clause": "ProcessStatus = 'Escalation'",
        "result_columns": [
            {"key": "customer_code", "label": "Customer Code", "column": "CustomerCode"},
            {"key": "node", "label": "Hierarchy Node", "column": "HierarchyNode"},
            {"key": "issue", "label": "Issue", "column": "IssueDescription"},
        ],
    },
]


HIERARCHY_PROCESS_REVIEW_FIELDS = [
    {"key": "all", "label": "All Configured Fields", "column": None},
    {"key": "master_id", "label": "MasterID", "column": "MasterID"},
    {"key": "master_id_corporate", "label": "MasterID_Corporate", "column": "MasterID Corporate"},
    {"key": "address", "label": "Address", "column": "Address"},
    {"key": "company_name", "label": "CompanyName", "column": "Name"},
]


HIERARCHY_PROCESS_REVIEW_COLUMNS = [
    {"key": "master_id", "label": "MasterID", "column": "MasterID"},
    {"key": "master_id_corporate", "label": "MasterID_Corporate", "column": "MasterID Corporate"},
    {"key": "company_name", "label": "CompanyName", "column": "Name"},
    {"key": "address", "label": "Address", "column": "Address"},
    {"key": "status", "label": "Status", "column": "ProcessStatus"},
]


def build_hierarchy_item_payload(item: dict, *, count: int, rows: list[dict]) -> dict:
    return {
        "id": item["id"],
        "label": item["label"],
        "severity": item["severity"],
        "description": item["description"],
        "source_table": item["source_table"],
        "columns": item["result_columns"],
        "rows": rows,
        "count": count,
        "review_tabs": REVIEW_TABS,
        "review_search_fields": HIERARCHY_PROCESS_REVIEW_FIELDS,
        "review_result_columns": HIERARCHY_PROCESS_REVIEW_COLUMNS,
    }
