SR_REQUEST_DEFINITION = {
    "label": "SR Request",
    "description": "Single-source request view for request tracking and review.",
    "source_table": "SR_Request_Table",
    "where_clause": "1 = 1",
    "result_columns": [
        {"key": "request_id", "label": "Request ID", "column": "RequestID"},
        {"key": "master_id", "label": "MasterID", "column": "MasterID"},
        {"key": "request_type", "label": "Request Type", "column": "RequestType"},
        {"key": "request_status", "label": "Status", "column": "RequestStatus"},
        {"key": "requested_by", "label": "Requested By", "column": "RequestedBy"},
    ],
}
