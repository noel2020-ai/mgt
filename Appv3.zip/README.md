# Hierarchy Anomaly Dashboard

FastAPI + Jinja2 application for monitoring customer-data anomalies, hierarchy process checks, and SR requests. The active app path is SQL Server direct and reference-driven: update table names, column mappings, and result columns in the reference files, then mount to the dev environment.

## Implementation plan

1. Keep the main tabs: `Dashboard`, `Data Quality`, `Hierarchy Process Ext.`, `SR Request`, and `Settings`.
2. Read `Data Quality`, `Hierarchy Process Ext.`, and `SR Request` directly from SQL Server in read-only mode.
3. Store table names, source columns, filters, and review behaviors in reference modules.
4. Keep frontend tables dynamic so backend column changes do not require template rewrites.

## Required environment variables

| Variable | Purpose |
|---|---|
| `APP_NAME` | Browser title and app header |
| `APP_ENV` | Runtime environment label |
| `APP_HOST` | Uvicorn host |
| `APP_PORT` | Uvicorn port |
| `LOG_LEVEL` | Logging level |
| `SECRET_KEY` | Reserved for future session/security use |
| `CORS_ORIGINS` | Allowed origins, comma-separated |
| `SQLSERVER_ENABLED` | Enables SQL Server-backed reads |
| `SQLSERVER_DRIVER` | ODBC driver name |
| `SQLSERVER_HOST` | SQL Server host |
| `SQLSERVER_PORT` | SQL Server port |
| `SQLSERVER_DATABASE` | SQL Server database |
| `SQLSERVER_TRUSTED_CONNECTION` | Enables Windows authentication for SQL Server |
| `SQLSERVER_USERNAME` | Read-only SQL login when trusted connection is off |
| `SQLSERVER_PASSWORD` | SQL Server password when trusted connection is off |
| `SQLSERVER_PREVIEW_ROW_LIMIT` | Max rows returned per page/query |

## Dev mount reference files

Update these files to point the app at the correct dev SQL Server tables and columns:

- [app/reference/anomaly_definitions.py](C:/Users/noel.fernandez/Desktop/SE Projects/Customer_Master_Dashboard/app/reference/anomaly_definitions.py)
- [app/reference/review_definitions.py](C:/Users/noel.fernandez/Desktop/SE Projects/Customer_Master_Dashboard/app/reference/review_definitions.py)
- [app/reference/hierarchy_process_definitions.py](C:/Users/noel.fernandez/Desktop/SE Projects/Customer_Master_Dashboard/app/reference/hierarchy_process_definitions.py)
- [app/reference/sr_request_definitions.py](C:/Users/noel.fernandez/Desktop/SE Projects/Customer_Master_Dashboard/app/reference/sr_request_definitions.py)

What you typically change there:

- `source_table`
- `result_columns`
- `column_map`
- `where_clause`
- review search fields and review result columns

## Setup commands

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

## Backend run command

```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Sample `.env`

```env
APP_NAME=Hierarchy Anomaly Dashboard
APP_ENV=development
APP_HOST=127.0.0.1
APP_PORT=8000
LOG_LEVEL=INFO
SECRET_KEY=change-me
CORS_ORIGINS=http://127.0.0.1:8000,http://localhost:8000
SQLSERVER_ENABLED=true
SQLSERVER_DRIVER=ODBC Driver 17 for SQL Server
SQLSERVER_HOST=localhost
SQLSERVER_PORT=1433
SQLSERVER_DATABASE=CustomerMaster
SQLSERVER_TRUSTED_CONNECTION=true
SQLSERVER_USERNAME=
SQLSERVER_PASSWORD=
SQLSERVER_PREVIEW_ROW_LIMIT=100
```

## Dev mount checklist

1. Set the real SQL Server connection values in `.env`.
2. Confirm the VM account has SQL Server read access.
3. Update all reference files to match real table names and column names.
4. Start the app.
5. Check `/api/sqlserver-preview`.
6. Check `/api/anomalies`.
7. Check `/api/hierarchy-process-ext/process-gaps`.
8. Open `/sr-request`.

## Notes

- SQL Server remains read-only.
- Only single-statement `SELECT` queries are allowed.
- Dangerous SQL keywords are rejected before execution.
- `Hierarchy Process Ext.` and `SR Request` are now also reference-driven, but you must point them to real dev tables before using them.
