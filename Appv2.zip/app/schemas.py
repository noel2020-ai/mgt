from pydantic import BaseModel


class ApiResponse(BaseModel):
    status: str
    message: str
    data: dict


class ValidationRunPayload(BaseModel):
    id: int
    status: str
    source_mode: str
    message: str
    records_loaded: int
    issues_found: int
    started_at: str
    finished_at: str | None
