import logging
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, declarative_base, sessionmaker

from app.config import get_settings

logger = logging.getLogger(__name__)

Base = declarative_base()
_engine: Engine | None = None
_session_factory: sessionmaker[Session] | None = None


def build_postgres_url() -> str:
    settings = get_settings()
    return (
        f"postgresql+psycopg://{settings.postgres_username}:{settings.postgres_password}"
        f"@{settings.postgres_host}:{settings.postgres_port}/{settings.postgres_database}"
    )


def get_engine() -> Engine:
    global _engine
    global _session_factory

    settings = get_settings()
    if not settings.postgres_enabled:
        raise RuntimeError("PostgreSQL is disabled. Enable it in the environment before using the database.")

    if _engine is None:
        logger.info("Initializing PostgreSQL engine for database '%s'.", settings.postgres_database)
        _engine = create_engine(
            build_postgres_url(),
            pool_pre_ping=True,
            future=True,
            echo=settings.postgres_echo,
        )
        _session_factory = sessionmaker(bind=_engine, autoflush=False, autocommit=False, future=True)

    return _engine


def get_session_factory() -> sessionmaker[Session]:
    global _session_factory

    if _session_factory is None:
        get_engine()
    assert _session_factory is not None
    return _session_factory


def get_db_session() -> Generator[Session, None, None]:
    session = get_session_factory()()
    try:
        yield session
    finally:
        session.close()
