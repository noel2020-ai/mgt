from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class ValidationRun(Base):
    __tablename__ = "validation_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False)
    source_mode: Mapped[str] = mapped_column(String(50), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False, default="")
    records_loaded: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    issues_found: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    raw_records: Mapped[list["RawHierarchyRecord"]] = relationship(back_populates="run")
    issues: Mapped[list["ValidationIssue"]] = relationship(back_populates="run")


class RawHierarchyRecord(Base):
    __tablename__ = "raw_hierarchy_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("validation_runs.id"), nullable=False, index=True)
    customer_code: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    node_code: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    parent_node_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    node_name: Mapped[str] = mapped_column(String(255), nullable=False)
    owner_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    owner_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    branch_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    source_system: Mapped[str] = mapped_column(String(50), nullable=False, default="unknown")

    run: Mapped["ValidationRun"] = relationship(back_populates="raw_records")


class ValidationIssue(Base):
    __tablename__ = "validation_issues"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("validation_runs.id"), nullable=False, index=True)
    issue_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(50), nullable=False)
    customer_code: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    node_code: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    details: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    run: Mapped["ValidationRun"] = relationship(back_populates="issues")
