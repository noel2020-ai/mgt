REVIEW_TABS = [
    {
        "id": "review1",
        "label": "Review1",
        "mode": "fixed",
        "search_field": "master_id",
        "placeholder": "Search MasterID",
        "help_text": "Search by MasterID.",
    },
    {
        "id": "review2",
        "label": "Review2",
        "mode": "fixed",
        "search_field": "master_id_corporate",
        "placeholder": "Search MasterID Corporate",
        "help_text": "Search by MasterID Corporate.",
    },
    {
        "id": "review3",
        "label": "Review3",
        "mode": "fixed",
        "search_field": "address",
        "placeholder": "Search Address",
        "help_text": "Search by Address.",
    },
    {
        "id": "review4",
        "label": "Review4",
        "mode": "fixed",
        "search_field": "company_name",
        "placeholder": "Search Company Name with wildcard",
        "help_text": "Use wildcard search for names, such as expc* or *pany.",
    },
    {
        "id": "review5",
        "label": "Review5",
        "mode": "custom",
        "search_field": "all",
        "placeholder": "Custom search",
        "help_text": "Choose a field and search any related item.",
    },
    {
        "id": "review6",
        "label": "Review6",
        "mode": "custom",
        "search_field": "all",
        "placeholder": "Custom comparison search",
        "help_text": "Use this panel for a second custom search to compare side by side.",
    },
]


TABLE_REVIEW_CONFIGS = {
    "cm_warehouse": {
        "search_fields": [
            {"key": "all", "label": "All Configured Fields", "column": None},
            {"key": "master_id", "label": "MasterID", "column": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate", "column": "MasterID Corporate"},
            {"key": "address", "label": "Address", "column": "Address"},
            {"key": "company_name", "label": "CompanyName", "column": "Name"},
        ],
        "result_columns": [
            {"key": "master_id", "label": "MasterID", "column": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate", "column": "MasterID Corporate"},
            {"key": "company_name", "label": "CompanyName", "column": "Name"},
            {"key": "address", "label": "Address", "column": "Address"},
            {"key": "flag", "label": "Flag", "column": "Headquarter Flag"},
            {"key": "owner_enterprise", "label": "Owner_Enterprise", "column": "Owner_Enterprise"},
        ],
    },
    "CM_Main_Table": {
        "search_fields": [
            {"key": "all", "label": "All Configured Fields", "column": None},
            {"key": "master_id", "label": "MasterID", "column": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate", "column": "MasterID Corporate"},
            {"key": "address", "label": "Address", "column": "Address"},
            {"key": "company_name", "label": "CompanyName", "column": "Name"},
        ],
        "result_columns": [
            {"key": "master_id", "label": "MasterID", "column": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate", "column": "MasterID Corporate"},
            {"key": "company_name", "label": "CompanyName", "column": "Name"},
            {"key": "address", "label": "Address", "column": "Address"},
            {"key": "primary_indicator", "label": "Primary", "column": "Primary"},
        ],
    },
}
