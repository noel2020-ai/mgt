from app.reference.review_definitions import REVIEW_TABS


HIERARCHY_PROCESS_ITEMS = [
    {
        "id": "process-gaps",
        "label": "Process Gaps",
        "severity": "high",
        "description": "Placeholder checks for missing steps or broken handoffs in the hierarchy process flow.",
        "source_table": "Hierarchy Process",
        "columns": [
            {"key": "customer_code", "label": "Customer Code"},
            {"key": "node", "label": "Hierarchy Node"},
            {"key": "issue", "label": "Issue"},
        ],
        "rows": [
            {"customer_code": "CUST-0401", "node": "Zone North", "issue": "Approval step missing"},
            {"customer_code": "CUST-0408", "node": "Zone West", "issue": "Handoff not completed"},
        ],
    },
    {
        "id": "timing-delays",
        "label": "Timing Delays",
        "severity": "medium",
        "description": "Placeholder checks for delays between process stages and refresh milestones.",
        "source_table": "Hierarchy Process",
        "columns": [
            {"key": "customer_code", "label": "Customer Code"},
            {"key": "node", "label": "Hierarchy Node"},
            {"key": "issue", "label": "Issue"},
        ],
        "rows": [
            {"customer_code": "CUST-0502", "node": "Retail Cluster A", "issue": "Stage delayed by 2 days"},
            {"customer_code": "CUST-0510", "node": "Retail Cluster D", "issue": "Refresh overdue"},
        ],
    },
    {
        "id": "owner-escalations",
        "label": "Owner Escalations",
        "severity": "critical",
        "description": "Placeholder checks for unresolved hierarchy process items that require escalation.",
        "source_table": "Hierarchy Process",
        "columns": [
            {"key": "customer_code", "label": "Customer Code"},
            {"key": "node", "label": "Hierarchy Node"},
            {"key": "issue", "label": "Issue"},
        ],
        "rows": [
            {"customer_code": "CUST-0601", "node": "National Accounts", "issue": "Escalation unresolved"},
            {"customer_code": "CUST-0604", "node": "Distributor Chain", "issue": "Owner not assigned"},
        ],
    },
]


HIERARCHY_PROCESS_REVIEW_FIELDS = [
    {"key": "master_id", "label": "MasterID"},
    {"key": "master_id_corporate", "label": "MasterID_Corporate"},
    {"key": "address", "label": "Address"},
    {"key": "company_name", "label": "CompanyName"},
]


HIERARCHY_PROCESS_REVIEW_COLUMNS = [
    {"key": "master_id", "label": "MasterID"},
    {"key": "master_id_corporate", "label": "MasterID_Corporate"},
    {"key": "company_name", "label": "CompanyName"},
    {"key": "address", "label": "Address"},
    {"key": "status", "label": "Status"},
]


HIERARCHY_PROCESS_REVIEW_ROWS = [
    {
        "master_id": "M-1001",
        "master_id_corporate": "MC-1001",
        "company_name": "ExpCompany Holdings",
        "address": "101 Main Street",
        "status": "Pending",
    },
    {
        "master_id": "M-1002",
        "master_id_corporate": "MC-1002",
        "company_name": "North Branch Company",
        "address": "25 River Road",
        "status": "Escalated",
    },
    {
        "master_id": "M-1003",
        "master_id_corporate": "MC-1003",
        "company_name": "Company Apex Retail",
        "address": "88 Market Avenue",
        "status": "Delayed",
    },
]


def build_hierarchy_item_payload(item: dict) -> dict:
    return {
        **item,
        "count": len(item["rows"]),
        "review_tabs": REVIEW_TABS,
        "review_search_fields": HIERARCHY_PROCESS_REVIEW_FIELDS,
        "review_result_columns": HIERARCHY_PROCESS_REVIEW_COLUMNS,
    }
