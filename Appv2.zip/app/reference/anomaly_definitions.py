ANOMALY_DEFINITIONS = [
    {
        "id": "hq-flag-masterid-mismatch",
        "label": "Headquarter Flag Mismatch",
        "severity": "high",
        "description": "Headquarter Flag is Y but MasterID is not equal to MasterID Corporate.",
        "source_table": "cm_warehouse",
        "column_map": {
            "master_id": "MasterID",
            "flag": "Headquarter Flag",
            "master_id_corporate": "MasterID Corporate",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "flag", "label": "Flag"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate"},
        ],
        "filter": {
            "type": "hq_flag_masterid_mismatch",
            "flag_value": "Y",
        },
        "review_config": {},
    },
    {
        "id": "bridge-masterid-corporate-missing",
        "label": "Bridge MasterID Corporate Missing",
        "severity": "high",
        "description": "MasterID Corporate does not exist in the MasterID column.",
        "source_table": "cm_warehouse",
        "column_map": {
            "master_id": "MasterID",
            "master_id_corporate": "MasterID Corporate",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate"},
        ],
        "filter": {
            "type": "masterid_corporate_not_in_masterid",
        },
        "review_config": {},
    },
    {
        "id": "masterid-corporate-not-hq",
        "label": "Master ID Corporate Not HQ",
        "severity": "high",
        "description": "Master ID Corporate exists in Master ID, but the HQ record does not have Flag = Y.",
        "source_table": "cm_warehouse",
        "column_map": {
            "master_id": "MasterID",
            "master_id_corporate": "MasterID Corporate",
            "flag": "Headquarter Flag",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate"},
            {"key": "flag", "label": "Flag"},
        ],
        "filter": {
            "type": "masterid_corporate_not_hq",
            "hq_flag_value": "Y",
        },
        "review_config": {},
    },
    {
        "id": "self-corporate-hq-flag-null",
        "label": "Self Corporate HQ Flag Null",
        "severity": "high",
        "description": "Master ID is equal to Master ID Corporate, but the HQ flag is null.",
        "source_table": "cm_warehouse",
        "column_map": {
            "master_id": "MasterID",
            "master_id_corporate": "MasterID Corporate",
            "flag": "Headquarter Flag",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate"},
            {"key": "flag", "label": "Flag"},
        ],
        "filter": {
            "type": "self_corporate_hq_flag_null",
        },
        "review_config": {},
    },
    {
        "id": "masterid-multiple-primary-records",
        "label": "MasterID Multiple Primary Records",
        "severity": "high",
        "description": "MasterIDs have more than one record with Indicator P in CM_Main_Table.",
        "source_table": "CM_Main_Table",
        "column_map": {
            "master_id": "MasterID",
            "primary_indicator": "Primary",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "primary_indicator", "label": "Primary"},
        ],
        "filter": {
            "type": "masterid_multiple_primary_records",
            "primary_value": "P",
        },
        "review_config": {},
    },
    {
        "id": "masterid-no-primary-record",
        "label": "MasterID No Primary Record",
        "severity": "high",
        "description": "MasterIDs have no Indicator P in CM_Main_Table and need one primary record.",
        "source_table": "CM_Main_Table",
        "column_map": {
            "master_id": "MasterID",
            "primary_indicator": "Primary",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "primary_indicator", "label": "Primary"},
        ],
        "filter": {
            "type": "masterid_no_primary_record",
            "primary_value": "P",
        },
        "review_config": {},
    },
    {
        "id": "masterid-no-address",
        "label": "MasterID No Address",
        "severity": "high",
        "description": "MasterIDs in CM_Main_Table do not have an Address value.",
        "source_table": "CM_Main_Table",
        "column_map": {
            "master_id": "MasterID",
            "address": "Address",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "address", "label": "Address"},
        ],
        "filter": {
            "type": "masterid_no_address",
        },
        "review_config": {},
    },
    {
        "id": "blank-masterid-corporate",
        "label": "Blank MasterID Corporate",
        "severity": "high",
        "description": "Records in CM_Main_Table have a blank MasterID Corporate.",
        "source_table": "CM_Main_Table",
        "column_map": {
            "master_id": "MasterID",
            "master_id_corporate": "MasterID Corporate",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate"},
        ],
        "filter": {
            "type": "blank_masterid_corporate",
        },
        "review_config": {},
    },
    {
        "id": "owner-enterprise-corporate-not-hq",
        "label": "Owner Enterprise Corporate Not HQ",
        "severity": "high",
        "description": "Records with Owner_Enterprise populated have a Master ID Corporate that is not flagged as HQ.",
        "source_table": "cm_warehouse",
        "column_map": {
            "master_id": "MasterID",
            "master_id_corporate": "MasterID Corporate",
            "flag": "Headquarter Flag",
            "owner_enterprise": "Owner_Enterprise",
        },
        "result_columns": [
            {"key": "master_id", "label": "MasterID"},
            {"key": "master_id_corporate", "label": "MasterID_Corporate"},
            {"key": "flag", "label": "Flag"},
            {"key": "owner_enterprise", "label": "Owner_Enterprise"},
        ],
        "filter": {
            "type": "owner_enterprise_corporate_not_hq",
            "hq_flag_value": "Y",
        },
        "review_config": {},
    },
]
