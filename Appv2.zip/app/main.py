from pathlib import Path
import logging

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.config import get_settings
from app.logging_config import configure_logging
from app.schemas import ApiResponse
from app.services.anomalies import (
    build_dashboard_summary,
    get_anomaly,
    get_anomaly_overview,
    list_anomalies,
    search_review_rows,
)
from app.services.hierarchy_process import get_hierarchy_item, list_hierarchy_items, search_hierarchy_reviews
from app.services.sqlserver_reader import SQLServerReadOnlyError, fetch_rows

settings = get_settings()
configure_logging(settings.log_level)
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title=settings.app_name)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


def render(
    request: Request,
    template_name: str,
    page_title: str,
    active_tab: str,
    **context: object,
) -> HTMLResponse:
    return templates.TemplateResponse(
        request=request,
        name=template_name,
        context={
            "app_name": settings.app_name,
            "page_title": page_title,
            "active_tab": active_tab,
            **context,
        },
    )


@app.get("/", response_class=HTMLResponse)
async def dashboard_page(request: Request) -> HTMLResponse:
    logger.info("Rendering dashboard page.")
    return render(
        request=request,
        template_name="dashboard.html",
        page_title="Dashboard",
        active_tab="dashboard",
        summary=build_dashboard_summary(),
        anomalies=list_anomalies(),
    )


@app.get("/data-quality", response_class=HTMLResponse)
async def data_quality_page(
    request: Request,
    anomaly: str | None = Query(default=None),
) -> HTMLResponse:
    anomalies = list_anomalies()
    selected = get_anomaly(anomaly) if anomaly else anomalies[0]
    if selected is None:
        raise HTTPException(status_code=404, detail="Anomaly not found.")

    logger.info("Rendering data quality page for anomaly '%s'.", selected["id"])
    return render(
        request=request,
        template_name="data_quality.html",
        page_title="Data Quality",
        active_tab="data_quality",
        anomalies=anomalies,
        selected_anomaly=selected,
    )


@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request) -> HTMLResponse:
    logger.info("Rendering settings page.")
    return render(
        request=request,
        template_name="settings.html",
        page_title="Settings",
        active_tab="settings",
        postgres_enabled=settings.postgres_enabled,
        postgres_host=settings.postgres_host,
        postgres_database=settings.postgres_database,
        sqlserver_enabled=settings.sqlserver_enabled,
        sqlserver_host=settings.sqlserver_host,
        sqlserver_database=settings.sqlserver_database,
        status_message=request.query_params.get("message"),
        status_level=request.query_params.get("level", "success"),
    )


@app.get("/sr-request", response_class=HTMLResponse)
async def sr_request_page(request: Request) -> HTMLResponse:
    logger.info("Rendering SR request page.")
    sr_request_rows = [
        {
            "request_id": "SR-1001",
            "master_id": "M-1001",
            "request_type": "Address Update",
            "request_status": "Open",
            "requested_by": "Operations Team",
        },
        {
            "request_id": "SR-1002",
            "master_id": "M-1002",
            "request_type": "Corporate Mapping",
            "request_status": "In Review",
            "requested_by": "Data Steward",
        },
    ]
    sr_request_columns = [
        {"key": "request_id", "label": "Request ID"},
        {"key": "master_id", "label": "MasterID"},
        {"key": "request_type", "label": "Request Type"},
        {"key": "request_status", "label": "Status"},
        {"key": "requested_by", "label": "Requested By"},
    ]
    return render(
        request=request,
        template_name="sr_request.html",
        page_title="SR Request",
        active_tab="sr_request",
        sr_request_columns=sr_request_columns,
        sr_request_rows=sr_request_rows,
    )


@app.get("/hierarchy-process-ext", response_class=HTMLResponse)
async def hierarchy_process_ext_page(request: Request) -> HTMLResponse:
    logger.info("Rendering hierarchy process extension page.")
    extension_items = list_hierarchy_items()
    selected_id = request.query_params.get("item")
    selected_item = next(
        (item for item in extension_items if item["id"] == selected_id),
        extension_items[0],
    )
    return render(
        request=request,
        template_name="hierarchy_process_ext.html",
        page_title="Hierarchy Process Ext.",
        active_tab="hierarchy_process_ext",
        extension_items=extension_items,
        selected_item=selected_item,
    )


@app.get("/api/hierarchy-process-ext/{item_id}", response_model=ApiResponse)
async def hierarchy_process_item_api(item_id: str) -> ApiResponse:
    item = get_hierarchy_item(item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hierarchy process item not found.")
    return ApiResponse(
        status="success",
        message="Hierarchy process item loaded.",
        data={"item": item},
    )


@app.get("/api/hierarchy-process-ext/{item_id}/reviews", response_model=ApiResponse)
async def hierarchy_process_reviews_api(
    item_id: str,
    review_tab: str = Query(default="review1"),
    search_field: str = Query(default="master_id"),
    search_text: str = Query(default=""),
) -> ApiResponse:
    item = get_hierarchy_item(item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hierarchy process item not found.")
    result = search_hierarchy_reviews(review_tab, search_field, search_text)
    return ApiResponse(
        status="success",
        message="Hierarchy review results loaded.",
        data=result,
    )

@app.get("/api/health", response_model=ApiResponse)
async def health_check() -> ApiResponse:
    return ApiResponse(
        status="success",
        message="Application is running.",
        data={
            "environment": settings.app_env,
            "sqlserver_enabled": settings.sqlserver_enabled,
        },
    )


@app.get("/api/anomalies", response_model=ApiResponse)
async def anomalies_api() -> ApiResponse:
    data = {"items": list_anomalies(), "summary": build_dashboard_summary()}
    return ApiResponse(status="success", message="Anomalies loaded.", data=data)


@app.get("/api/anomalies/{anomaly_id}", response_model=ApiResponse)
async def anomaly_detail_api(anomaly_id: str) -> ApiResponse:
    anomaly = get_anomaly(anomaly_id)
    if anomaly is None:
        raise HTTPException(status_code=404, detail="Anomaly not found.")
    return ApiResponse(
        status="success",
        message="Anomaly detail loaded.",
        data={"item": anomaly},
    )


@app.get("/api/anomalies/{anomaly_id}/overview", response_model=ApiResponse)
async def anomaly_overview_api(anomaly_id: str) -> ApiResponse:
    anomaly = get_anomaly_overview(anomaly_id)
    if anomaly is None:
        raise HTTPException(status_code=404, detail="Anomaly not found.")
    return ApiResponse(
        status="success",
        message="Anomaly overview loaded.",
        data={"item": anomaly},
    )


@app.get("/api/anomalies/{anomaly_id}/reviews", response_model=ApiResponse)
async def anomaly_review_api(
    anomaly_id: str,
    review_tab: str = Query(default="review1"),
    search_field: str = Query(default="all"),
    search_text: str = Query(default=""),
) -> ApiResponse:
    result = search_review_rows(anomaly_id, review_tab, search_field, search_text)
    if result is None:
        raise HTTPException(status_code=404, detail="Anomaly not found.")
    return ApiResponse(
        status="success",
        message="Review results loaded.",
        data=result,
    )


@app.get("/api/sqlserver-preview", response_model=ApiResponse)
async def sqlserver_preview(query: str = Query(default="SELECT TOP 10 name FROM sys.tables")) -> ApiResponse:
    if not settings.sqlserver_enabled:
        return ApiResponse(
            status="success",
            message="SQL Server integration is disabled. Returning placeholder response.",
            data={"items": [], "query": query},
        )

    try:
        rows = fetch_rows(settings, query)
    except SQLServerReadOnlyError as exc:
        logger.warning("Rejected SQL Server query: %s", exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception:
        logger.exception("SQL Server preview query failed.")
        raise HTTPException(status_code=500, detail="SQL Server preview query failed.") from None

    return ApiResponse(
        status="success",
        message="SQL Server preview query completed.",
        data={"items": rows, "query": query},
    )
