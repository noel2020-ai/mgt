from __future__ import annotations

import logging
from collections import Counter, defaultdict
from datetime import datetime

from sqlalchemy import desc, func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import RawHierarchyRecord, ValidationIssue, ValidationRun
from app.services.sqlserver_reader import fetch_rows

logger = logging.getLogger(__name__)

ISSUE_META = {
    "missing-parent": {"label": "Missing Parent Links", "severity": "high"},
    "duplicate-assignments": {"label": "Duplicate Assignments", "severity": "medium"},
    "circular-reference": {"label": "Circular References", "severity": "critical"},
    "inactive-owner": {"label": "Inactive Owner Mapping", "severity": "low"},
}


def load_source_rows() -> tuple[list[dict], str]:
    settings = get_settings()
    if settings.sqlserver_enabled:
        logger.info("Loading hierarchy source rows from SQL Server.")
        return fetch_rows(settings, settings.sqlserver_validation_query), "sqlserver"

    logger.info("SQL Server is disabled. Using dummy hierarchy rows for validation.")
    return _dummy_source_rows(), "dummy"


def start_validation_run(session: Session, source_mode: str) -> ValidationRun:
    run = ValidationRun(
        status="running",
        source_mode=source_mode,
        message="Validation run started.",
        started_at=datetime.utcnow(),
    )
    session.add(run)
    session.commit()
    session.refresh(run)
    return run


def complete_validation_run(
    session: Session,
    run: ValidationRun,
    *,
    status: str,
    message: str,
    records_loaded: int,
    issues_found: int,
) -> ValidationRun:
    run.status = status
    run.message = message
    run.records_loaded = records_loaded
    run.issues_found = issues_found
    run.finished_at = datetime.utcnow()
    session.add(run)
    session.commit()
    session.refresh(run)
    return run


def fail_validation_run(session: Session, run: ValidationRun, message: str) -> None:
    run.status = "failed"
    run.message = message
    run.finished_at = datetime.utcnow()
    session.add(run)
    session.commit()


def ingest_raw_layer(session: Session, run_id: int, source_rows: list[dict], source_mode: str) -> int:
    logger.info("Ingesting %s source rows into PostgreSQL raw layer.", len(source_rows))
    records = [
        RawHierarchyRecord(
            run_id=run_id,
            customer_code=str(row.get("customer_code", "")).strip(),
            node_code=str(row.get("node_code", "")).strip(),
            parent_node_code=_normalize_optional_string(row.get("parent_node_code")),
            node_name=str(row.get("node_name", "")).strip() or "Unknown Node",
            owner_name=_normalize_optional_string(row.get("owner_name")),
            owner_active=_normalize_bool(row.get("owner_active")),
            branch_name=_normalize_optional_string(row.get("branch_name")),
            source_system=source_mode,
        )
        for row in source_rows
    ]
    session.add_all(records)
    session.commit()
    return len(records)


def process_validation_layer(session: Session) -> ValidationRun:
    source_rows, source_mode = load_source_rows()
    run = start_validation_run(session, source_mode)

    try:
        records_loaded = ingest_raw_layer(session, run.id, source_rows, source_mode)
        issues = build_validation_issues(source_rows, run.id)
        session.add_all(issues)
        session.commit()

        run = complete_validation_run(
            session,
            run,
            status="completed",
            message="Validation layer processed successfully.",
            records_loaded=records_loaded,
            issues_found=len(issues),
        )
        logger.info(
            "Validation layer complete for run %s. Loaded %s records and found %s issues.",
            run.id,
            records_loaded,
            len(issues),
        )
        return run
    except Exception as exc:
        logger.exception("Validation layer processing failed for run %s.", run.id)
        fail_validation_run(session, run, f"Validation layer failed: {exc}")
        raise


def get_latest_validation_run(session: Session) -> ValidationRun | None:
    stmt = select(ValidationRun).order_by(desc(ValidationRun.started_at)).limit(1)
    return session.scalar(stmt)


def get_validation_summary(session: Session) -> dict | None:
    latest_run = get_latest_validation_run(session)
    if latest_run is None or latest_run.status != "completed":
        return None

    issue_counts = dict(
        session.execute(
            select(ValidationIssue.issue_type, func.count(ValidationIssue.id))
            .where(ValidationIssue.run_id == latest_run.id)
            .group_by(ValidationIssue.issue_type)
        ).all()
    )
    severity_counts = dict(
        session.execute(
            select(ValidationIssue.severity, func.count(ValidationIssue.id))
            .where(ValidationIssue.run_id == latest_run.id)
            .group_by(ValidationIssue.severity)
        ).all()
    )

    return {
        "total_anomalies": len(issue_counts),
        "total_records_flagged": sum(issue_counts.values()),
        "critical_items": severity_counts.get("critical", 0),
        "high_items": severity_counts.get("high", 0),
        "trend_text": f"Latest validation run #{latest_run.id} completed from {latest_run.source_mode}.",
        "pipeline_status": latest_run.status.title(),
    }


def get_validation_anomalies(session: Session) -> list[dict] | None:
    latest_run = get_latest_validation_run(session)
    if latest_run is None or latest_run.status != "completed":
        return None

    counts = dict(
        session.execute(
            select(ValidationIssue.issue_type, func.count(ValidationIssue.id))
            .where(ValidationIssue.run_id == latest_run.id)
            .group_by(ValidationIssue.issue_type)
        ).all()
    )

    sample_rows = session.execute(
        select(ValidationIssue)
        .where(ValidationIssue.run_id == latest_run.id)
        .order_by(ValidationIssue.created_at.asc())
    ).scalars()

    grouped_samples: dict[str, list[ValidationIssue]] = defaultdict(list)
    for issue in sample_rows:
        if len(grouped_samples[issue.issue_type]) < 5:
            grouped_samples[issue.issue_type].append(issue)

    anomalies = []
    for issue_type, meta in ISSUE_META.items():
        if issue_type not in counts:
            continue
        anomalies.append(
            {
                "id": issue_type,
                "label": meta["label"],
                "severity": meta["severity"],
                "count": counts[issue_type],
                "description": _issue_description(issue_type),
                "samples": [
                    {
                        "customer_code": sample.customer_code or "-",
                        "node": sample.node_code or "-",
                        "issue": sample.details,
                    }
                    for sample in grouped_samples[issue_type]
                ],
            }
        )

    return anomalies


def serialize_validation_run(run: ValidationRun | None) -> dict | None:
    if run is None:
        return None
    return {
        "id": run.id,
        "status": run.status,
        "source_mode": run.source_mode,
        "message": run.message,
        "records_loaded": run.records_loaded,
        "issues_found": run.issues_found,
        "started_at": run.started_at.isoformat(),
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
    }


def build_validation_issues(source_rows: list[dict], run_id: int) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    node_codes = {str(row.get("node_code", "")).strip() for row in source_rows}

    customer_counts = Counter(str(row.get("customer_code", "")).strip() for row in source_rows)
    duplicate_customers = {customer for customer, count in customer_counts.items() if customer and count > 1}

    row_by_node = {
        str(row.get("node_code", "")).strip(): _normalize_optional_string(row.get("parent_node_code"))
        for row in source_rows
    }
    cyclic_nodes = detect_circular_nodes(row_by_node)

    for row in source_rows:
        customer_code = str(row.get("customer_code", "")).strip() or None
        node_code = str(row.get("node_code", "")).strip() or None
        parent_node_code = _normalize_optional_string(row.get("parent_node_code"))
        owner_name = _normalize_optional_string(row.get("owner_name"))
        owner_active = _normalize_bool(row.get("owner_active"))

        if parent_node_code and parent_node_code not in node_codes:
            issues.append(
                ValidationIssue(
                    run_id=run_id,
                    issue_type="missing-parent",
                    severity=ISSUE_META["missing-parent"]["severity"],
                    customer_code=customer_code,
                    node_code=node_code,
                    details=f"Parent node '{parent_node_code}' was not found in the loaded hierarchy.",
                )
            )

        if customer_code in duplicate_customers:
            issues.append(
                ValidationIssue(
                    run_id=run_id,
                    issue_type="duplicate-assignments",
                    severity=ISSUE_META["duplicate-assignments"]["severity"],
                    customer_code=customer_code,
                    node_code=node_code,
                    details="Customer appears multiple times in the hierarchy source.",
                )
            )

        if node_code in cyclic_nodes:
            issues.append(
                ValidationIssue(
                    run_id=run_id,
                    issue_type="circular-reference",
                    severity=ISSUE_META["circular-reference"]["severity"],
                    customer_code=customer_code,
                    node_code=node_code,
                    details="Node participates in a circular parent-child reference.",
                )
            )

        if not owner_name or not owner_active:
            issues.append(
                ValidationIssue(
                    run_id=run_id,
                    issue_type="inactive-owner",
                    severity=ISSUE_META["inactive-owner"]["severity"],
                    customer_code=customer_code,
                    node_code=node_code,
                    details="Owner is missing or inactive for this hierarchy record.",
                )
            )

    return issues


def detect_circular_nodes(node_parent_map: dict[str, str | None]) -> set[str]:
    cyclic_nodes: set[str] = set()

    for node in node_parent_map:
        seen: set[str] = set()
        current = node
        while current:
            if current in seen:
                cyclic_nodes.update(seen)
                break
            seen.add(current)
            current = node_parent_map.get(current)

    return cyclic_nodes


def _issue_description(issue_type: str) -> str:
    descriptions = {
        "missing-parent": "Records point to a parent node that does not exist in the loaded hierarchy layer.",
        "duplicate-assignments": "The same customer appears under multiple hierarchy branches in the validation layer.",
        "circular-reference": "A hierarchy path loops back to an ancestor and breaks traversal logic.",
        "inactive-owner": "Hierarchy owners are inactive or missing in the loaded validation dataset.",
    }
    return descriptions[issue_type]


def _normalize_optional_string(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _normalize_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _dummy_source_rows() -> list[dict]:
    return [
        {
            "customer_code": "CUST-0011",
            "node_code": "NODE-100",
            "parent_node_code": "NODE-ROOT",
            "node_name": "South Cluster",
            "owner_name": "Ana Reyes",
            "owner_active": True,
            "branch_name": "South",
        },
        {
            "customer_code": "CUST-0011",
            "node_code": "NODE-101",
            "parent_node_code": "NODE-999",
            "node_name": "South Cluster Duplicate",
            "owner_name": "Ana Reyes",
            "owner_active": True,
            "branch_name": "South",
        },
        {
            "customer_code": "CUST-0084",
            "node_code": "NODE-102",
            "parent_node_code": "NODE-100",
            "node_name": "Metro Tier 2",
            "owner_name": None,
            "owner_active": False,
            "branch_name": "Metro",
        },
        {
            "customer_code": "CUST-0221",
            "node_code": "NODE-103",
            "parent_node_code": "NODE-104",
            "node_name": "Distributor Group A",
            "owner_name": "Marco Lim",
            "owner_active": True,
            "branch_name": "National",
        },
        {
            "customer_code": "CUST-0222",
            "node_code": "NODE-104",
            "parent_node_code": "NODE-103",
            "node_name": "Distributor Group B",
            "owner_name": "Marco Lim",
            "owner_active": True,
            "branch_name": "National",
        },
    ]
