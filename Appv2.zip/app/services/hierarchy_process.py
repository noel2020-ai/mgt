from app.reference.hierarchy_process_definitions import (
    HIERARCHY_PROCESS_ITEMS,
    HIERARCHY_PROCESS_REVIEW_COLUMNS,
    HIERARCHY_PROCESS_REVIEW_ROWS,
    build_hierarchy_item_payload,
)


def list_hierarchy_items() -> list[dict]:
    return [build_hierarchy_item_payload(item) for item in HIERARCHY_PROCESS_ITEMS]


def get_hierarchy_item(item_id: str) -> dict | None:
    for item in HIERARCHY_PROCESS_ITEMS:
        if item["id"] == item_id:
            return build_hierarchy_item_payload(item)
    return None


def search_hierarchy_reviews(review_tab: str, search_field: str, search_text: str) -> dict:
    if not search_text.strip():
        return {
            "review_tab": review_tab,
            "search_field": search_field,
            "search_text": search_text,
            "columns": HIERARCHY_PROCESS_REVIEW_COLUMNS,
            "rows": [],
            "message": "Enter a search term to review related records.",
        }

    normalized = search_text.strip().lower()
    pattern = normalized.replace("*", "")
    rows = []
    for row in HIERARCHY_PROCESS_REVIEW_ROWS:
        value = str(row.get(search_field, "") if search_field != "all" else " ".join(str(v) for v in row.values())).lower()
        if "*" in normalized:
            if normalized.startswith("*") and value.endswith(pattern):
                rows.append(row)
            elif normalized.endswith("*") and value.startswith(pattern):
                rows.append(row)
            elif pattern in value:
                rows.append(row)
        elif normalized in value:
            rows.append(row)

    return {
        "review_tab": review_tab,
        "search_field": search_field,
        "search_text": search_text,
        "columns": HIERARCHY_PROCESS_REVIEW_COLUMNS,
        "rows": rows,
        "message": f"{len(rows)} related records found.",
    }
