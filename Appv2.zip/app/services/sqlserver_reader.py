import logging
import re

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from app.config import Settings

logger = logging.getLogger(__name__)

FORBIDDEN_SQL_PATTERN = re.compile(
    r"\b(insert|update|delete|drop|alter|truncate|merge|exec|create|replace|grant|revoke)\b",
    re.IGNORECASE,
)


class SQLServerReadOnlyError(Exception):
    pass


def validate_read_only_query(query: str) -> str:
    normalized = query.strip()
    if not normalized:
        raise SQLServerReadOnlyError("Query cannot be empty.")
    if ";" in normalized:
        raise SQLServerReadOnlyError("Multiple statements are not allowed.")
    if not normalized.lower().startswith("select"):
        raise SQLServerReadOnlyError("Only SELECT statements are allowed.")
    if FORBIDDEN_SQL_PATTERN.search(normalized):
        raise SQLServerReadOnlyError("Query contains forbidden SQL keywords.")
    return normalized


def build_engine(settings: Settings) -> Engine:
    logger.info("Initializing SQL Server read-only engine for database '%s'.", settings.sqlserver_database)
    return create_engine(settings.sqlserver_url, pool_pre_ping=True, future=True)


def fetch_rows(settings: Settings, query: str) -> list[dict]:
    validated_query = validate_read_only_query(query)
    engine = build_engine(settings)

    logger.info("Executing read-only SQL Server query.")
    with engine.connect() as connection:
        result = connection.execute(text(validated_query))
        return [dict(row._mapping) for row in result]
