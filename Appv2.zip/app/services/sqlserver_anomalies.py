import logging
import re

from app.config import get_settings
from app.reference.anomaly_definitions import ANOMALY_DEFINITIONS
from app.reference.review_definitions import REVIEW_TABS, TABLE_REVIEW_CONFIGS
from app.services.sqlserver_reader import fetch_rows

logger = logging.getLogger(__name__)

IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_ ]*$")
ALIAS_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class SQLServerAnomalyConfigError(Exception):
    pass


def list_anomalies() -> list[dict]:
    items = []
    for definition in ANOMALY_DEFINITIONS:
        items.append(_serialize_anomaly(definition, include_rows=True))
    logger.info("Loaded %s anomaly definitions.", len(items))
    return items


def get_anomaly(anomaly_id: str) -> dict | None:
    definition = _get_definition(anomaly_id)
    if definition is not None:
        return _serialize_anomaly(definition, include_rows=True)
    return None


def get_anomaly_overview(anomaly_id: str) -> dict | None:
    definition = _get_definition(anomaly_id)
    if definition is not None:
        return _serialize_anomaly(definition, include_rows=False)
    return None


def search_review_rows(
    anomaly_id: str,
    review_tab: str,
    search_field: str,
    search_text: str,
) -> dict | None:
    definition = _get_definition(anomaly_id)
    if definition is None:
        return None

    review_config = _build_review_config(definition)
    panel = next((tab for tab in review_config["tabs"] if tab["id"] == review_tab), None)
    if panel is None:
        raise SQLServerAnomalyConfigError(f"Unsupported review tab: {review_tab}")

    effective_search_field = panel["search_field"] if panel["mode"] == "fixed" else search_field

    if not search_text.strip():
        return {
            "review_tab": review_tab,
            "search_field": effective_search_field,
            "search_text": search_text,
            "columns": review_config["result_columns"],
            "rows": [],
            "message": "Enter a search term to review related records.",
        }

    settings = get_settings()
    if not settings.sqlserver_enabled:
        return {
            "review_tab": review_tab,
            "search_field": effective_search_field,
            "search_text": search_text,
            "columns": review_config["result_columns"],
            "rows": [],
            "message": "SQL Server is disabled.",
        }

    query = build_review_query(
        definition["source_table"],
        review_config,
        effective_search_field,
        search_text,
        settings.sqlserver_preview_row_limit,
    )
    rows = fetch_rows(settings, query)
    return {
        "review_tab": review_tab,
        "search_field": effective_search_field,
        "search_text": search_text,
        "columns": review_config["result_columns"],
        "rows": rows,
        "message": f"{len(rows)} related records found.",
    }


def build_dashboard_summary() -> dict:
    anomalies = list_anomalies()
    return {
        "total_anomalies": len(anomalies),
        "total_records_flagged": sum(item["count"] for item in anomalies),
        "critical_items": sum(1 for item in anomalies if item["severity"] == "critical"),
        "high_items": sum(1 for item in anomalies if item["severity"] == "high"),
        "trend_text": "Direct SQL Server anomaly scan from configured reference checks.",
        "pipeline_status": "SQL Server direct" if anomalies else "No anomaly definitions",
    }


def _load_rows(definition: dict) -> list[dict]:
    settings = get_settings()
    if not settings.sqlserver_enabled:
        return []

    query = build_anomaly_query(definition, settings.sqlserver_preview_row_limit)
    source_rows = fetch_rows(settings, query)
    return [
        {column["key"]: row.get(column["key"]) for column in definition["result_columns"]}
        for row in source_rows
    ]


def _serialize_anomaly(definition: dict, *, include_rows: bool) -> dict:
    rows = _load_rows(definition) if include_rows else []
    review_config = _build_review_config(definition)
    return {
        "id": definition["id"],
        "label": definition["label"],
        "severity": definition["severity"],
        "description": definition["description"],
        "count": len(rows) if include_rows else _count_rows(definition),
        "columns": definition["result_columns"],
        "rows": rows,
        "source_table": definition["source_table"],
        "review_tabs": review_config["tabs"],
        "review_search_fields": review_config["search_fields"],
        "review_result_columns": review_config["result_columns"],
    }


def _count_rows(definition: dict) -> int:
    settings = get_settings()
    if not settings.sqlserver_enabled:
        return 0
    count_query = build_anomaly_count_query(definition)
    count_rows = fetch_rows(settings, count_query)
    if not count_rows:
        return 0
    return int(count_rows[0].get("row_count", 0) or 0)


def _build_review_config(definition: dict) -> dict:
    table_defaults = TABLE_REVIEW_CONFIGS.get(definition["source_table"], {})
    override = definition.get("review_config", {})
    return {
        "tabs": override.get("tabs", REVIEW_TABS),
        "search_fields": override.get("search_fields", table_defaults.get("search_fields", [])),
        "result_columns": override.get("result_columns", table_defaults.get("result_columns", [])),
    }


def _get_definition(anomaly_id: str) -> dict | None:
    for definition in ANOMALY_DEFINITIONS:
        if definition["id"] == anomaly_id:
            return definition
    return None


def build_anomaly_query(definition: dict, row_limit: int) -> str:
    select_parts = []
    for column in definition["result_columns"]:
        select_parts.append(
            build_select_expression(
                definition["filter"],
                definition["column_map"],
                definition["source_table"],
                column["key"],
            )
        )

    return (
        f"SELECT TOP {int(row_limit)} {', '.join(select_parts)} "
        f"FROM {quote_identifier(definition['source_table'])} "
        f"WHERE {build_where_clause(definition['filter'], definition['column_map'], definition['source_table'])}"
    )


def build_anomaly_count_query(definition: dict) -> str:
    return (
        f"SELECT COUNT(1) AS [row_count] "
        f"FROM {quote_identifier(definition['source_table'])} "
        f"WHERE {build_where_clause(definition['filter'], definition['column_map'], definition['source_table'])}"
    )


def build_review_query(
    source_table: str,
    review_config: dict,
    search_field: str,
    search_text: str,
    row_limit: int,
) -> str:
    search_fields = review_config["search_fields"]
    result_columns = review_config["result_columns"]
    valid_search_keys = {field["key"] for field in search_fields}
    if search_field not in valid_search_keys:
        raise SQLServerAnomalyConfigError(f"Unsupported review search field: {search_field}")

    select_parts = [
        f"{quote_identifier(column['column'])} AS {quote_alias(column['key'])}"
        for column in result_columns
    ]
    where_clause = build_review_where_clause(search_fields, search_field, search_text)
    return (
        f"SELECT TOP {int(row_limit)} {', '.join(select_parts)} "
        f"FROM {quote_identifier(source_table)} "
        f"WHERE {where_clause}"
    )


def build_review_where_clause(search_fields: list[dict], search_field: str, search_text: str) -> str:
    pattern = build_like_pattern(search_text)

    if search_field == "all":
        expressions = [
            like_expression(field["column"], pattern)
            for field in search_fields
            if field["column"] is not None
        ]
        return " OR ".join(f"({expression})" for expression in expressions)

    for field in search_fields:
        if field["key"] == search_field:
            return like_expression(field["column"], pattern)

    raise SQLServerAnomalyConfigError(f"Unsupported review search field: {search_field}")


def build_like_pattern(search_text: str) -> str:
    normalized = search_text.strip()
    escaped = escape_sql_string(normalized)
    if "*" in escaped:
        return escaped.replace("*", "%")
    return f"%{escaped}%"


def like_expression(column_name: str, pattern: str) -> str:
    column = quote_identifier(column_name)
    return f"UPPER(ISNULL(CAST({column} AS NVARCHAR(255)), '')) LIKE UPPER('{pattern}')"


def build_select_expression(
    filter_definition: dict,
    column_map: dict,
    source_table: str,
    column_key: str,
) -> str:
    filter_type = filter_definition["type"]

    if filter_type in {"masterid_corporate_not_hq", "owner_enterprise_corporate_not_hq"} and column_key == "flag":
        master_id_column = quote_identifier(column_map["master_id"])
        corporate_column = quote_identifier(column_map["master_id_corporate"])
        flag_column = quote_identifier(column_map["flag"])
        return (
            f"(SELECT TOP 1 [hq_src].{flag_column} "
            f"FROM {quote_identifier(source_table)} AS [hq_src] "
            f"WHERE ISNULL(CAST([hq_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '')) AS {quote_alias(column_key)}"
        )

    source_column = column_map[column_key]
    return f"{quote_identifier(source_column)} AS {quote_alias(column_key)}"


def build_where_clause(filter_definition: dict, column_map: dict, source_table: str) -> str:
    filter_type = filter_definition["type"]
    if filter_type == "hq_flag_masterid_mismatch":
        flag_column = quote_identifier(column_map["flag"])
        master_id_column = quote_identifier(column_map["master_id"])
        corporate_column = quote_identifier(column_map["master_id_corporate"])
        flag_value = escape_sql_string(filter_definition["flag_value"])

        return (
            f"{flag_column} = '{flag_value}' "
            f"AND ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') "
            f"<> ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '')"
        )

    if filter_type == "masterid_corporate_not_in_masterid":
        master_id_column = quote_identifier(column_map["master_id"])
        corporate_column = quote_identifier(column_map["master_id_corporate"])
        return (
            f"ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '') <> '' "
            f"AND NOT EXISTS ("
            f"SELECT 1 FROM {quote_identifier(source_table)} AS [lookup_src] "
            f"WHERE ISNULL(CAST([lookup_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '')"
            f")"
        )

    if filter_type == "masterid_corporate_not_hq":
        master_id_column = quote_identifier(column_map["master_id"])
        corporate_column = quote_identifier(column_map["master_id_corporate"])
        flag_column = quote_identifier(column_map["flag"])
        hq_flag_value = escape_sql_string(filter_definition["hq_flag_value"])
        return (
            f"ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '') <> '' "
            f"AND EXISTS ("
            f"SELECT 1 FROM {quote_identifier(source_table)} AS [lookup_src] "
            f"WHERE ISNULL(CAST([lookup_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '')"
            f") "
            f"AND NOT EXISTS ("
            f"SELECT 1 FROM {quote_identifier(source_table)} AS [hq_src] "
            f"WHERE ISNULL(CAST([hq_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '') "
            f"AND ISNULL(CAST([hq_src].{flag_column} AS NVARCHAR(255)), '') = '{hq_flag_value}'"
            f")"
        )

    if filter_type == "owner_enterprise_corporate_not_hq":
        master_id_column = quote_identifier(column_map["master_id"])
        corporate_column = quote_identifier(column_map["master_id_corporate"])
        flag_column = quote_identifier(column_map["flag"])
        owner_enterprise_column = quote_identifier(column_map["owner_enterprise"])
        hq_flag_value = escape_sql_string(filter_definition["hq_flag_value"])
        return (
            f"NULLIF(LTRIM(RTRIM(CAST({owner_enterprise_column} AS NVARCHAR(255)))), '') IS NOT NULL "
            f"AND ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '') <> '' "
            f"AND EXISTS ("
            f"SELECT 1 FROM {quote_identifier(source_table)} AS [lookup_src] "
            f"WHERE ISNULL(CAST([lookup_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '')"
            f") "
            f"AND NOT EXISTS ("
            f"SELECT 1 FROM {quote_identifier(source_table)} AS [hq_src] "
            f"WHERE ISNULL(CAST([hq_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '') "
            f"AND ISNULL(CAST([hq_src].{flag_column} AS NVARCHAR(255)), '') = '{hq_flag_value}'"
            f")"
        )

    if filter_type == "self_corporate_hq_flag_null":
        master_id_column = quote_identifier(column_map["master_id"])
        corporate_column = quote_identifier(column_map["master_id_corporate"])
        flag_column = quote_identifier(column_map["flag"])
        return (
            f"ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') <> '' "
            f"AND ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({corporate_column} AS NVARCHAR(255)), '') "
            f"AND NULLIF(LTRIM(RTRIM(CAST({flag_column} AS NVARCHAR(255)))), '') IS NULL"
        )

    if filter_type == "masterid_multiple_primary_records":
        master_id_column = quote_identifier(column_map["master_id"])
        primary_indicator_column = quote_identifier(column_map["primary_indicator"])
        primary_value = escape_sql_string(filter_definition["primary_value"])
        return (
            f"ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') <> '' "
            f"AND ISNULL(CAST({primary_indicator_column} AS NVARCHAR(255)), '') = '{primary_value}' "
            f"AND ("
            f"SELECT COUNT(1) FROM {quote_identifier(source_table)} AS [primary_src] "
            f"WHERE ISNULL(CAST([primary_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') "
            f"AND ISNULL(CAST([primary_src].{primary_indicator_column} AS NVARCHAR(255)), '') = '{primary_value}'"
            f") > 1"
        )

    if filter_type == "masterid_no_primary_record":
        master_id_column = quote_identifier(column_map["master_id"])
        primary_indicator_column = quote_identifier(column_map["primary_indicator"])
        primary_value = escape_sql_string(filter_definition["primary_value"])
        return (
            f"ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') <> '' "
            f"AND NOT EXISTS ("
            f"SELECT 1 FROM {quote_identifier(source_table)} AS [primary_src] "
            f"WHERE ISNULL(CAST([primary_src].{master_id_column} AS NVARCHAR(255)), '') "
            f"= ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') "
            f"AND ISNULL(CAST([primary_src].{primary_indicator_column} AS NVARCHAR(255)), '') = '{primary_value}'"
            f")"
        )

    if filter_type == "masterid_no_address":
        master_id_column = quote_identifier(column_map["master_id"])
        address_column = quote_identifier(column_map["address"])
        return (
            f"ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') <> '' "
            f"AND NULLIF(LTRIM(RTRIM(CAST({address_column} AS NVARCHAR(255)))), '') IS NULL"
        )

    if filter_type == "blank_masterid_corporate":
        master_id_column = quote_identifier(column_map["master_id"])
        corporate_column = quote_identifier(column_map["master_id_corporate"])
        return (
            f"ISNULL(CAST({master_id_column} AS NVARCHAR(255)), '') <> '' "
            f"AND NULLIF(LTRIM(RTRIM(CAST({corporate_column} AS NVARCHAR(255)))), '') IS NULL"
        )

    raise SQLServerAnomalyConfigError(f"Unsupported anomaly filter type: {filter_type}")


def quote_identifier(value: str) -> str:
    if not IDENTIFIER_PATTERN.match(value):
        raise SQLServerAnomalyConfigError(f"Unsafe SQL identifier: {value}")
    return f"[{value}]"


def quote_alias(value: str) -> str:
    if not ALIAS_PATTERN.match(value):
        raise SQLServerAnomalyConfigError(f"Unsafe SQL alias: {value}")
    return f"[{value}]"


def escape_sql_string(value: str) -> str:
    return value.replace("'", "''")
