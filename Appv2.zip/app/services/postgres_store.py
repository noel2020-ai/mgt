import logging

from sqlalchemy.exc import SQLAlchemyError

from app.database import Base, get_engine
from app import models  # noqa: F401

logger = logging.getLogger(__name__)


def initialize_schema() -> None:
    engine = get_engine()
    logger.info("Ensuring PostgreSQL schema exists.")
    try:
        Base.metadata.create_all(bind=engine)
    except SQLAlchemyError:
        logger.exception("Failed to initialize PostgreSQL schema.")
        raise
