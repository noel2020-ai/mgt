# Hierarchy Anomaly Dashboard

FastAPI + Jinja2 application for monitoring hierarchy-process anomalies. The current implementation reads anomaly data directly from SQL Server in read-only mode and renders flexible result tables based on backend reference definitions.

## Implementation plan

1. Build a FastAPI application with server-rendered Jinja2 templates.
2. Keep the main tabs: `Dashboard`, `Data Quality`, `Hierarchy Process Ext.`, and `Settings`.
3. Read anomaly data directly from SQL Server table sources.
4. Store anomaly table names, source columns, filter rules, and returned columns in a reference module.
5. Keep the frontend table layout dynamic so backend column changes do not require template rewrites.

## Required environment variables

The app reads configuration from `.env`.

| Variable | Purpose |
|---|---|
| `APP_NAME` | Browser title and app header |
| `APP_ENV` | Runtime environment label |
| `APP_HOST` | Uvicorn host |
| `APP_PORT` | Uvicorn port |
| `LOG_LEVEL` | Logging level |
| `SECRET_KEY` | Reserved for future session/security use |
| `CORS_ORIGINS` | Allowed origins, comma-separated |
| `SQLSERVER_ENABLED` | Enables SQL Server-backed anomaly reads |
| `SQLSERVER_DRIVER` | ODBC driver name |
| `SQLSERVER_HOST` | SQL Server host |
| `SQLSERVER_PORT` | SQL Server port |
| `SQLSERVER_DATABASE` | SQL Server database |
| `SQLSERVER_TRUSTED_CONNECTION` | Enables Windows authentication for SQL Server |
| `SQLSERVER_USERNAME` | Read-only SQL login when trusted connection is off |
| `SQLSERVER_PASSWORD` | SQL Server password when trusted connection is off |
| `SQLSERVER_PREVIEW_ROW_LIMIT` | Max rows returned per anomaly query |

## Folder structure

```text
Customer_Master_Dashboard/
├── app/
│   ├── config.py
│   ├── logging_config.py
│   ├── main.py
│   ├── reference/
│   │   └── anomaly_definitions.py
│   └── services/
│       ├── anomalies.py
│       ├── sqlserver_anomalies.py
│       └── sqlserver_reader.py
├── static/
│   └── css/
│       └── styles.css
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── data_quality.html
│   ├── hierarchy_process_ext.html
│   └── settings.html
├── .env.example
├── README.md
└── requirements.txt
```

## Current anomaly reference

The first live anomaly is defined in [app/reference/anomaly_definitions.py](C:/Users/noel.fernandez/Desktop/SE Projects/Customer_Master_Dashboard/app/reference/anomaly_definitions.py).

- Source table: `cm_warehouse`
- Rule: `Headquarter Flag = 'Y'` and `MasterID <> MasterID Corporate`
- Returned columns:
  - `MasterID`
  - `Flag`
  - `MasterID_Corporate`

To change source columns later, edit `column_map`.

To change displayed output columns later, edit `result_columns`.

## Flexible frontend behavior

The `Data Quality` table is column-driven. The backend returns:

- `columns`: labels and keys to render
- `rows`: row values keyed by those column keys

The template reads that structure directly, so adding or removing columns in the backend definition does not require changing the table markup.

## Setup commands

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

## Backend run command

```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Frontend run command

There is no separate frontend build tool in this version. The UI is rendered by FastAPI + Jinja2.

Open:

```text
http://127.0.0.1:8000
```

## Sample `.env` values

```env
APP_NAME=Hierarchy Anomaly Dashboard
APP_ENV=development
APP_HOST=127.0.0.1
APP_PORT=8000
LOG_LEVEL=INFO
SECRET_KEY=change-me
CORS_ORIGINS=http://127.0.0.1:8000,http://localhost:8000
SQLSERVER_ENABLED=true
SQLSERVER_DRIVER=ODBC Driver 17 for SQL Server
SQLSERVER_HOST=localhost
SQLSERVER_PORT=1433
SQLSERVER_DATABASE=CustomerMaster
SQLSERVER_TRUSTED_CONNECTION=true
SQLSERVER_USERNAME=
SQLSERVER_PASSWORD=
SQLSERVER_PREVIEW_ROW_LIMIT=100
```

## Basic test steps

1. Start the app with Uvicorn.
2. Open `http://127.0.0.1:8000`.
3. Open `Data Quality`.
4. Confirm the first anomaly loads from `cm_warehouse`.
5. Confirm the table headers match the configured `result_columns`.
6. Check `http://127.0.0.1:8000/api/health`.
7. Check `http://127.0.0.1:8000/api/anomalies`.
8. Check `http://127.0.0.1:8000/api/sqlserver-preview`.

## Data source notes

- The dashboard reads anomaly results directly from SQL Server.
- SQL Server remains read-only.
- Only single-statement `SELECT` queries are allowed.
- Dangerous SQL keywords are rejected before execution.
- If the VM uses Windows authentication, set `SQLSERVER_TRUSTED_CONNECTION=true`.
- Update anomaly mappings in `app/reference/anomaly_definitions.py`.

## Placeholder integrations

- Google Search API: not implemented
- Hoovers / D&B integration: not implemented
