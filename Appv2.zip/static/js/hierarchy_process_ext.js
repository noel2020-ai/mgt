(function () {
    const state = {
        selectedItemId: window.hierarchyInitialState.selectedItemId,
        reviewPanels: {},
    };

    const sideButtons = Array.from(document.querySelectorAll("[data-hierarchy-item-id]"));
    const overviewCards = Array.from(document.querySelectorAll("[data-overview-card]"));
    const titleEl = document.getElementById("hierarchy-title");
    const descriptionEl = document.getElementById("hierarchy-description");
    const severityEl = document.getElementById("hierarchy-severity");
    const countEl = document.getElementById("hierarchy-count");
    const sourceTableEl = document.getElementById("hierarchy-source-table");
    const queryTableEl = document.getElementById("hierarchy-results-table");
    const reviewGridEl = document.getElementById("hierarchy-review-grid");

    renderItem(window.hierarchyInitialState.selectedItem);
    bindEvents();

    function bindEvents() {
        sideButtons.forEach((button) => {
            button.addEventListener("click", async () => {
                const itemId = button.dataset.hierarchyItemId;
                if (!itemId || itemId === state.selectedItemId) {
                    return;
                }
                const item = await fetchItem(itemId);
                if (!item) {
                    return;
                }
                state.selectedItemId = itemId;
                state.reviewPanels = {};
                renderItem(item);
                window.history.replaceState({}, "", `/hierarchy-process-ext?item=${itemId}`);
            });
        });
    }

    function renderItem(item) {
        titleEl.textContent = item.label;
        descriptionEl.textContent = item.description;
        severityEl.textContent = item.severity;
        severityEl.className = `badge ${item.severity}`;
        countEl.textContent = item.count;
        sourceTableEl.textContent = item.source_table;
        renderSelectionState(item.id);
        renderOverviewCards(item.id);
        renderDataTable(queryTableEl, item.columns, item.rows, "No records found.");
        renderReviewPanels(item);
    }

    function renderSelectionState(selectedId) {
        sideButtons.forEach((button) => {
            button.classList.toggle("active", button.dataset.hierarchyItemId === selectedId);
        });
    }

    function renderOverviewCards(selectedId) {
        overviewCards.forEach((card) => {
            card.classList.toggle("selected", card.dataset.overviewCard === selectedId);
        });
    }

    function renderReviewPanels(item) {
        state.reviewPanels = {};
        reviewGridEl.innerHTML = item.review_tabs
            .map((tab) => {
                const allowFieldSelect = tab.mode === "custom";
                const options = item.review_search_fields
                    .map((field) => `<option value="${escapeHtml(field.key)}" ${field.key === tab.search_field ? "selected" : ""}>${escapeHtml(field.label)}</option>`)
                    .join("");
                return `
                    <section class="review-panel">
                        <div class="review-panel-head">
                            <div>
                                <h4>${escapeHtml(tab.label)}</h4>
                                <p class="subtle">${escapeHtml(tab.help_text)}</p>
                            </div>
                            <span class="review-chip">${escapeHtml(tab.search_field)}</span>
                        </div>
                        <form class="review-panel-form" data-h-review-form="${escapeHtml(tab.id)}">
                            ${allowFieldSelect ? `<select data-h-review-search-field="${escapeHtml(tab.id)}">${options}</select>` : ""}
                            <input type="text" data-h-review-search-text="${escapeHtml(tab.id)}" placeholder="${escapeHtml(tab.placeholder)}">
                            <button type="submit" class="action-button">Search</button>
                        </form>
                        <p class="subtle review-panel-message" data-h-review-message="${escapeHtml(tab.id)}">Enter a search term to review related records.</p>
                        <div class="table-wrap">
                            <table data-h-review-table="${escapeHtml(tab.id)}"></table>
                        </div>
                    </section>
                `;
            })
            .join("");

        item.review_tabs.forEach((tab) => {
            state.reviewPanels[tab.id] = { searchField: tab.search_field, searchText: "" };
            const form = reviewGridEl.querySelector(`[data-h-review-form="${tab.id}"]`);
            const table = reviewGridEl.querySelector(`[data-h-review-table="${tab.id}"]`);
            renderDataTable(table, item.review_result_columns, [], "Enter a search term to review related records.");
            form.addEventListener("submit", async (event) => {
                event.preventDefault();
                const input = reviewGridEl.querySelector(`[data-h-review-search-text="${tab.id}"]`);
                const select = reviewGridEl.querySelector(`[data-h-review-search-field="${tab.id}"]`);
                state.reviewPanels[tab.id].searchText = input.value.trim();
                state.reviewPanels[tab.id].searchField = select ? select.value : tab.search_field;
                await loadReviewResults(tab.id, item.review_result_columns);
            });
        });
    }

    async function loadReviewResults(reviewTabId, resultColumns) {
        const panelState = state.reviewPanels[reviewTabId];
        const params = new URLSearchParams({
            review_tab: reviewTabId,
            search_field: panelState.searchField || "all",
            search_text: panelState.searchText || "",
        });
        const response = await fetch(`/api/hierarchy-process-ext/${encodeURIComponent(state.selectedItemId)}/reviews?${params.toString()}`);
        const messageEl = reviewGridEl.querySelector(`[data-h-review-message="${reviewTabId}"]`);
        const tableEl = reviewGridEl.querySelector(`[data-h-review-table="${reviewTabId}"]`);
        if (!response.ok) {
            messageEl.textContent = "Review search failed.";
            renderDataTable(tableEl, resultColumns, [], "Review search failed.");
            return;
        }
        const payload = await response.json();
        const data = payload.data;
        messageEl.textContent = data.message;
        renderDataTable(tableEl, data.columns, data.rows, data.message);
    }

    async function fetchItem(itemId) {
        const response = await fetch(`/api/hierarchy-process-ext/${encodeURIComponent(itemId)}`);
        if (!response.ok) {
            return null;
        }
        const payload = await response.json();
        return payload.data.item;
    }

    function renderDataTable(tableEl, columns, rows, emptyMessage) {
        const header = `<thead><tr>${columns.map((column) => `<th>${escapeHtml(column.label)}</th>`).join("")}</tr></thead>`;
        const bodyRows = rows.length
            ? rows.map((row) => `<tr>${columns.map((column) => `<td>${escapeHtml(formatValue(row[column.key]))}</td>`).join("")}</tr>`).join("")
            : `<tr><td colspan="${columns.length || 1}">${escapeHtml(emptyMessage)}</td></tr>`;
        tableEl.innerHTML = `${header}<tbody>${bodyRows}</tbody>`;
    }

    function formatValue(value) {
        if (value === null || value === undefined || value === "") {
            return "-";
        }
        return String(value);
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }
})();
