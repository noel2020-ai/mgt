(function () {
    const state = {
        selectedAnomalyId: window.dataQualityInitialState.selectedAnomalyId,
        reviewPanels: {},
    };

    const sideButtons = Array.from(document.querySelectorAll("[data-anomaly-id]"));
    const overviewCards = Array.from(document.querySelectorAll("[data-overview-card]"));
    const titleEl = document.getElementById("anomaly-title");
    const descriptionEl = document.getElementById("anomaly-description");
    const severityEl = document.getElementById("anomaly-severity");
    const countEl = document.getElementById("anomaly-count");
    const sourceTableEl = document.getElementById("anomaly-source-table");
    const queryTableEl = document.getElementById("query-results-table");
    const reviewGridEl = document.getElementById("review-grid");

    renderAnomaly(window.dataQualityInitialState.selectedAnomaly);
    bindEvents();

    function bindEvents() {
        sideButtons.forEach((button) => {
            button.addEventListener("click", async () => {
                const anomalyId = button.dataset.anomalyId;
                if (!anomalyId || anomalyId === state.selectedAnomalyId) {
                    return;
                }
                const anomaly = await fetchAnomaly(anomalyId);
                if (!anomaly) {
                    return;
                }
                state.selectedAnomalyId = anomalyId;
                state.reviewPanels = {};
                renderAnomaly(anomaly);
                window.history.replaceState({}, "", `/data-quality?anomaly=${anomalyId}`);
            });
        });
    }

    function renderAnomaly(anomaly) {
        titleEl.textContent = anomaly.label;
        descriptionEl.textContent = anomaly.description;
        severityEl.textContent = anomaly.severity;
        severityEl.className = `badge ${anomaly.severity}`;
        countEl.textContent = anomaly.count;
        sourceTableEl.textContent = anomaly.source_table;

        renderSelectionState(anomaly.id);
        renderOverviewCards(anomaly.id);
        renderDataTable(queryTableEl, anomaly.columns, anomaly.rows, "No records found.");
        renderReviewPanels(anomaly);
    }

    function renderSelectionState(selectedId) {
        sideButtons.forEach((button) => {
            button.classList.toggle("active", button.dataset.anomalyId === selectedId);
        });
    }

    function renderOverviewCards(selectedId) {
        overviewCards.forEach((card) => {
            card.classList.toggle("selected", card.dataset.overviewCard === selectedId);
        });
    }

    function renderReviewPanels(anomaly) {
        state.reviewPanels = {};
        reviewGridEl.innerHTML = anomaly.review_tabs
            .map((tab) => {
                const allowFieldSelect = tab.mode === "custom";
                const options = anomaly.review_search_fields
                    .map((field) => `<option value="${escapeHtml(field.key)}" ${field.key === tab.search_field ? "selected" : ""}>${escapeHtml(field.label)}</option>`)
                    .join("");
                return `
                    <section class="review-panel" data-review-panel="${escapeHtml(tab.id)}">
                        <div class="review-panel-head">
                            <div>
                                <h4>${escapeHtml(tab.label)}</h4>
                                <p class="subtle">${escapeHtml(tab.help_text)}</p>
                            </div>
                            <span class="review-chip">${escapeHtml(tab.search_field)}</span>
                        </div>
                        <form class="review-panel-form" data-review-form="${escapeHtml(tab.id)}">
                            ${allowFieldSelect ? `<select data-review-search-field="${escapeHtml(tab.id)}">${options}</select>` : ""}
                            <input
                                type="text"
                                data-review-search-text="${escapeHtml(tab.id)}"
                                placeholder="${escapeHtml(tab.placeholder)}"
                            >
                            <button type="submit" class="action-button">Search</button>
                        </form>
                        <p class="subtle review-panel-message" data-review-message="${escapeHtml(tab.id)}">Enter a search term to review related records.</p>
                        <div class="table-wrap">
                            <table data-review-table="${escapeHtml(tab.id)}"></table>
                        </div>
                    </section>
                `;
            })
            .join("");

        anomaly.review_tabs.forEach((tab) => {
            state.reviewPanels[tab.id] = {
                searchField: tab.search_field,
                searchText: "",
                mode: tab.mode,
            };
            const form = reviewGridEl.querySelector(`[data-review-form="${tab.id}"]`);
            const table = reviewGridEl.querySelector(`[data-review-table="${tab.id}"]`);
            renderDataTable(table, anomaly.review_result_columns, [], "Enter a search term to review related records.");
            form.addEventListener("submit", async (event) => {
                event.preventDefault();
                const input = reviewGridEl.querySelector(`[data-review-search-text="${tab.id}"]`);
                const select = reviewGridEl.querySelector(`[data-review-search-field="${tab.id}"]`);
                state.reviewPanels[tab.id].searchText = input.value.trim();
                state.reviewPanels[tab.id].searchField = select ? select.value : tab.search_field;
                await loadReviewResults(tab.id, anomaly.review_result_columns);
            });
        });
    }

    async function loadReviewResults(reviewTabId, resultColumns) {
        const anomalyId = state.selectedAnomalyId;
        const panelState = state.reviewPanels[reviewTabId];
        const params = new URLSearchParams({
            review_tab: reviewTabId,
            search_field: panelState.searchField || "all",
            search_text: panelState.searchText || "",
        });
        const response = await fetch(`/api/anomalies/${encodeURIComponent(anomalyId)}/reviews?${params.toString()}`);
        const messageEl = reviewGridEl.querySelector(`[data-review-message="${reviewTabId}"]`);
        const tableEl = reviewGridEl.querySelector(`[data-review-table="${reviewTabId}"]`);

        if (!response.ok) {
            messageEl.textContent = "Review search failed.";
            renderDataTable(tableEl, resultColumns, [], "Review search failed.");
            return;
        }

        const payload = await response.json();
        const data = payload.data;
        messageEl.textContent = data.message;
        renderDataTable(tableEl, data.columns, data.rows, data.message);
    }

    async function fetchAnomaly(anomalyId) {
        const response = await fetch(`/api/anomalies/${encodeURIComponent(anomalyId)}`);
        if (!response.ok) {
            return null;
        }
        const payload = await response.json();
        return payload.data.item;
    }

    function renderDataTable(tableEl, columns, rows, emptyMessage) {
        const header = `
            <thead>
                <tr>${columns.map((column) => `<th>${escapeHtml(column.label)}</th>`).join("")}</tr>
            </thead>
        `;
        const bodyRows = rows.length
            ? rows
                  .map(
                      (row) => `
                <tr>
                    ${columns.map((column) => `<td>${escapeHtml(formatValue(row[column.key]))}</td>`).join("")}
                </tr>
            `
                  )
                  .join("")
            : `<tr><td colspan="${columns.length || 1}">${escapeHtml(emptyMessage)}</td></tr>`;
        tableEl.innerHTML = `${header}<tbody>${bodyRows}</tbody>`;
    }

    function formatValue(value) {
        if (value === null || value === undefined || value === "") {
            return "-";
        }
        return String(value);
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }
})();
